import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  Trophy, Target, TrendingUp, BarChart3, Calendar,
  CheckCircle2, Zap, Crown, Loader2, Star, Award,
  ChevronDown, ChevronUp, DollarSign, Users
} from "lucide-react";
import { ACTIVE_SPORTS } from "@shared/platform-config";

interface TrackRecordPlayer {
  name: string;
  position: string;
  team: string;
  salary: number;
  projectedPoints: number;
  actualPoints: number;
  value: number;
  boostScore: number;
}

interface TrackRecordEntry {
  id: number;
  sport: string;
  slateDate: string;
  totalActualPoints: number;
  totalSalary: number;
  salaryCap: number;
  salaryUtilization: number;
  playerData: TrackRecordPlayer[];
  avgProjectionRatio: number | null;
  boostHitRate: number | null;
  outperformanceMultiple: number | null;
  poolAvgActual: number | null;
}

interface SportBreakdown {
  count: number;
  avgScore: number;
  avgAccuracy: number;
  avgSalaryUtil: number;
}

interface TrackRecordData {
  records: TrackRecordEntry[];
  summary: {
    totalSlatesAnalyzed: number;
    avgProjectionAccuracy: number | null;
    sportBreakdown: Record<string, SportBreakdown>;
  };
}

const SPORT_COLORS: Record<string, { text: string; bg: string; border: string }> = {
  NBA: { text: "text-orange-400", bg: "bg-orange-500/10", border: "border-orange-500/20" },
  NHL: { text: "text-cyan-400", bg: "bg-cyan-500/10", border: "border-cyan-500/20" },
  MLB: { text: "text-red-400", bg: "bg-red-500/10", border: "border-red-500/20" },
  NFL: { text: "text-green-400", bg: "bg-green-500/10", border: "border-green-500/20" },
  GOLF: { text: "text-lime-400", bg: "bg-lime-500/10", border: "border-lime-500/20" },
  SOCCER: { text: "text-teal-400", bg: "bg-teal-500/10", border: "border-teal-500/20" },
};

function AccuracyGrade(ratio: number | null): { grade: string; color: string; label: string } {
  if (ratio === null) return { grade: "—", color: "text-slate-500", label: "No data" };
  const pct = ratio * 100;
  if (pct >= 100) return { grade: "A+", color: "text-emerald-400", label: "Beat projection" };
  if (pct >= 95) return { grade: "A", color: "text-emerald-400", label: "Near perfect" };
  if (pct >= 90) return { grade: "B+", color: "text-amber-400", label: "Strong" };
  if (pct >= 85) return { grade: "B", color: "text-amber-400", label: "Good" };
  if (pct >= 80) return { grade: "C", color: "text-orange-400", label: "Average" };
  return { grade: "D", color: "text-red-400", label: "Below avg" };
}

function RecordRow({ record }: { record: TrackRecordEntry }) {
  const [expanded, setExpanded] = useState(false);
  const colors = SPORT_COLORS[record.sport] || SPORT_COLORS.NBA;
  const grade = AccuracyGrade(record.avgProjectionRatio);
  const outperformPct = record.outperformanceMultiple
    ? Math.round((record.outperformanceMultiple - 1) * 100)
    : null;

  return (
    <div className="border-b border-slate-800/60 last:border-0">
      {/* Main row */}
      <div
        className="px-5 py-4 flex items-center gap-4 cursor-pointer hover:bg-slate-800/20 transition-colors"
        onClick={() => setExpanded(e => !e)}
      >
        <div className="shrink-0 w-20">
          <p className="text-xs font-black text-white">
            {new Date(record.slateDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
          </p>
          <p className="text-[10px] text-slate-500">
            {new Date(record.slateDate).getFullYear()}
          </p>
        </div>

        <Badge className={`${colors.bg} ${colors.text} ${colors.border} text-[10px] font-black shrink-0`}>
          {record.sport}
        </Badge>

        <div className="flex-1 min-w-0 grid grid-cols-3 gap-4">
          {/* Optimal score */}
          <div>
            <p className="text-lg font-black text-white tabular-nums">{record.totalActualPoints.toFixed(1)}</p>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Optimal Score</p>
          </div>

          {/* Salary utilization */}
          <div>
            <p className="text-sm font-black text-slate-300">{record.salaryUtilization.toFixed(1)}%</p>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Salary Used</p>
            <div className="w-full h-1 bg-slate-800 rounded-full mt-1 overflow-hidden">
              <div
                className="h-full bg-emerald-600 rounded-full"
                style={{ width: `${Math.min(100, record.salaryUtilization)}%` }}
              />
            </div>
          </div>

          {/* Projection accuracy grade */}
          <div>
            <p className={`text-lg font-black ${grade.color}`}>{grade.grade}</p>
            <p className="text-[10px] text-slate-500 font-bold uppercase">
              {record.avgProjectionRatio ? `${Math.round(record.avgProjectionRatio * 100)}% accuracy` : "Proj. Accuracy"}
            </p>
          </div>
        </div>

        {/* Outperformance vs field */}
        {outperformPct !== null && (
          <div className="text-right shrink-0 hidden md:block">
            <p className={`text-sm font-black tabular-nums ${outperformPct >= 0 ? "text-emerald-400" : "text-red-400"}`}>
              {outperformPct >= 0 ? "+" : ""}{outperformPct}%
            </p>
            <p className="text-[10px] text-slate-500 font-bold uppercase">vs field</p>
          </div>
        )}

        {expanded
          ? <ChevronUp className="w-4 h-4 text-slate-500 shrink-0" />
          : <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
        }
      </div>

      {/* Expanded player breakdown */}
      {expanded && (
        <div className="px-5 pb-4 bg-slate-950/40">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 pt-3">
            Optimal Lineup Players
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {(record.playerData as TrackRecordPlayer[]).map((p, i) => (
              <div key={i} className="flex items-center gap-3 bg-slate-800/30 rounded-lg px-3 py-2">
                <span className="text-[10px] font-black text-slate-500 w-8 shrink-0">{p.position}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-white truncate">{p.name}</p>
                  <p className="text-[10px] text-slate-500">{p.team} · ${p.salary.toLocaleString()}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-black text-emerald-400">{p.actualPoints.toFixed(1)}</p>
                  <p className="text-[10px] text-slate-500">proj {p.projectedPoints.toFixed(1)}</p>
                </div>
                {p.boostScore > 0 && (
                  <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/20 text-[9px] font-black shrink-0">
                    AI ↑
                  </Badge>
                )}
              </div>
            ))}
          </div>

          {/* Extra stats */}
          <div className="flex gap-4 mt-3 pt-3 border-t border-slate-800/50">
            {record.boostHitRate !== null && (
              <div>
                <p className="text-sm font-black text-white">{record.boostHitRate}%</p>
                <p className="text-[10px] text-slate-500 uppercase">AI Boost Hit Rate</p>
              </div>
            )}
            {record.poolAvgActual !== null && (
              <div>
                <p className="text-sm font-black text-slate-300">{record.poolAvgActual.toFixed(1)}</p>
                <p className="text-[10px] text-slate-500 uppercase">Avg Player Score</p>
              </div>
            )}
            <div>
              <p className="text-sm font-black text-slate-300">${record.totalSalary.toLocaleString()}</p>
              <p className="text-[10px] text-slate-500 uppercase">Salary Used</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function TrackRecord() {
  const [selectedSport, setSelectedSport] = useState<string>("ALL");

  const { data, isLoading } = useQuery<TrackRecordData>({
    queryKey: ["/api/track-record", selectedSport],
    queryFn: async () => {
      const url = selectedSport === "ALL"
        ? "/api/track-record"
        : `/api/track-record?sport=${selectedSport}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to load track record");
      return res.json();
    },
    staleTime: 300000,
  });

  const summary = data?.summary;
  const records = data?.records || [];

  // Overall accuracy % label
  const accuracyLabel = summary?.avgProjectionAccuracy
    ? `${summary.avgProjectionAccuracy}%`
    : null;

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-950/60 via-slate-950/80 to-slate-950" />
        <div className="relative max-w-5xl mx-auto px-6 pt-12 pb-10">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="text-xs font-black text-emerald-400 uppercase tracking-widest">Verified Results</span>
          </div>
          <h1 className="text-4xl font-black text-white mb-3 leading-tight">
            Algorithm<br />Track Record
          </h1>
          <p className="text-slate-400 max-w-lg text-sm leading-relaxed mb-6">
            Every optimal lineup our algorithm would have generated, compared against actual DFS results.
            No cherry-picking — every slate, every sport, every day.
          </p>

          {/* Top-line stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl">
            {[
              {
                label: "Slates Analyzed",
                value: summary?.totalSlatesAnalyzed ?? "—",
                icon: <Calendar className="w-4 h-4 text-slate-400" />,
              },
              {
                label: "Avg Accuracy",
                value: accuracyLabel ?? "—",
                icon: <Target className="w-4 h-4 text-emerald-400" />,
                highlight: true,
              },
              {
                label: "Sports Covered",
                value: Object.keys(summary?.sportBreakdown || {}).length || ACTIVE_SPORTS.length,
                icon: <Trophy className="w-4 h-4 text-amber-400" />,
              },
              {
                label: "Updated",
                value: "Nightly",
                icon: <Zap className="w-4 h-4 text-amber-400" />,
              },
            ].map(stat => (
              <div
                key={stat.label}
                className={`rounded-xl p-4 border ${
                  stat.highlight
                    ? "bg-emerald-500/10 border-emerald-500/25"
                    : "bg-slate-900/60 border-slate-700/40"
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1">{stat.icon}</div>
                <p className={`text-2xl font-black ${stat.highlight ? "text-emerald-400" : "text-white"}`}>
                  {stat.value}
                </p>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-6 space-y-6">
        {/* Sport breakdown cards */}
        {summary && Object.keys(summary.sportBreakdown).length > 0 && (
          <div>
            <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3">By Sport</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(summary.sportBreakdown).map(([sport, stats]) => {
                const colors = SPORT_COLORS[sport] || SPORT_COLORS.NBA;
                return (
                  <Card
                    key={sport}
                    onClick={() => setSelectedSport(sport === selectedSport ? "ALL" : sport)}
                    className={`p-4 cursor-pointer transition-all ${
                      selectedSport === sport
                        ? `${colors.bg} ${colors.border} border-2`
                        : "bg-slate-900/60 border-slate-700/40 hover:border-slate-600/60"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-sm font-black ${colors.text}`}>{sport}</span>
                      <span className="text-[10px] font-bold text-slate-500">{stats.count} slates</span>
                    </div>
                    <p className="text-xl font-black text-white">{stats.avgScore.toFixed(1)}</p>
                    <p className="text-[10px] text-slate-500 uppercase mb-2">avg optimal score</p>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-400">Accuracy: <span className="text-white font-bold">{stats.avgAccuracy}%</span></span>
                      <span className="text-slate-400">Salary: <span className="text-white font-bold">{stats.avgSalaryUtil}%</span></span>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Sport filter */}
        <div className="flex gap-1 bg-slate-800/60 rounded-lg p-1 border border-slate-700/50 w-fit">
          {["ALL", ...ACTIVE_SPORTS].map(s => (
            <button
              key={s}
              onClick={() => setSelectedSport(s)}
              className={`px-3 py-1.5 rounded-md text-[11px] font-black transition-all ${
                selectedSport === s
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Results table */}
        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
          </div>
        ) : records.length === 0 ? (
          <Card className="bg-slate-900 border-slate-700 p-12 text-center">
            <BarChart3 className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-white mb-2">No Results Yet</h3>
            <p className="text-sm text-slate-400">
              {selectedSport === "ALL"
                ? "Track record data is generated nightly after game results are finalized. Check back after the next slate."
                : `No ${selectedSport} slates have been analyzed yet.`}
            </p>
          </Card>
        ) : (
          <Card className="bg-slate-900/70 border-slate-700/50 overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">
                Optimal Lineup Results — {records.length} Slates
              </p>
              <p className="text-[10px] text-slate-500">Click any row to see the lineup</p>
            </div>
            <div className="divide-y divide-slate-800/50">
              {records.map(record => (
                <RecordRow key={record.id} record={record} />
              ))}
            </div>
          </Card>
        )}

        {/* Conversion CTA at bottom */}
        <Card className="bg-gradient-to-r from-emerald-950/60 to-slate-900/60 border-emerald-500/20 p-8 text-center">
          <Award className="w-10 h-10 text-emerald-400 mx-auto mb-4" />
          <h3 className="text-xl font-black text-white mb-2">Ready to Build Lineups Like These?</h3>
          <p className="text-sm text-slate-400 mb-6 max-w-md mx-auto">
            The same algorithm that generates these optimal lineups is available in the Pro Optimizer.
            Build up to 20 lineups at once with AI boosts and real-time injury adjustments.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <Link href="/pricing">
              <Button className="bg-amber-500 hover:bg-amber-600 text-black font-black h-11 px-6">
                <Crown className="w-4 h-4 mr-2" /> View Plans
              </Button>
            </Link>
            <Link href="/optimizer">
              <Button variant="outline" className="border-emerald-500/30 text-emerald-400 h-11 px-6 font-bold">
                <Zap className="w-4 h-4 mr-2" /> Try Free
              </Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
