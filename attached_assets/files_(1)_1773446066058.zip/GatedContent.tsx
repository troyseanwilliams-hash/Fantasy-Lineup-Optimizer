// GatedContent.tsx
// ============================================================
// Drop-in blur/teaser component for gating content by tier.
// Usage:
//   <GatedContent
//     hasAccess={isPaidUser}
//     blurIntensity="medium"
//     upgradeMessage="Upgrade to see all 47 players"
//     upgradeCtaLabel="Unlock All Players"
//   >
//     <YourContent />
//   </GatedContent>
//
// Also exports:
//   - GatedPlayerRows: wraps a table body, shows first N rows, blurs the rest
//   - GatedLineupCards: shows first N lineup cards, blurs the rest
//   - GatedBadge: inline lock badge for labeling premium content
// ============================================================

import { Link } from "wouter";
import { Crown, Lock, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

// ── Core GatedContent wrapper ─────────────────────────────────────────────────

interface GatedContentProps {
  hasAccess: boolean;
  children: React.ReactNode;
  upgradeMessage?: string;
  upgradeCtaLabel?: string;
  upgradeTo?: string; // plan name shown in badge
  blurIntensity?: "light" | "medium" | "heavy";
  overlayPosition?: "center" | "bottom";
  minHeight?: string;
  className?: string;
}

export function GatedContent({
  hasAccess,
  children,
  upgradeMessage = "Upgrade to unlock this feature",
  upgradeCtaLabel = "Upgrade Now",
  upgradeTo = "Champion",
  blurIntensity = "medium",
  overlayPosition = "center",
  minHeight = "120px",
  className = "",
}: GatedContentProps) {
  if (hasAccess) return <>{children}</>;

  const blurClass =
    blurIntensity === "light" ? "blur-[3px]" :
    blurIntensity === "medium" ? "blur-[6px]" :
    "blur-[10px]";

  return (
    <div className={`relative ${className}`} style={{ minHeight }}>
      {/* Blurred content underneath */}
      <div className={`${blurClass} select-none pointer-events-none opacity-60`} aria-hidden>
        {children}
      </div>

      {/* Overlay */}
      <div className={`absolute inset-0 flex flex-col items-center justify-${overlayPosition === "bottom" ? "end pb-6" : "center"} bg-gradient-to-t from-slate-950/90 via-slate-950/60 to-transparent`}>
        <div className="text-center px-6 max-w-xs">
          <div className="w-10 h-10 rounded-full bg-amber-500/15 border border-amber-500/25 flex items-center justify-center mx-auto mb-3">
            <Lock className="w-5 h-5 text-amber-400" />
          </div>
          <p className="text-sm font-bold text-white mb-1">{upgradeMessage}</p>
          <p className="text-xs text-slate-400 mb-4">Available on {upgradeTo}</p>
          <Link href="/pricing">
            <Button size="sm" className="bg-amber-500 hover:bg-amber-600 text-black font-black text-xs h-8 px-4">
              <Crown className="w-3.5 h-3.5 mr-1.5" />
              {upgradeCtaLabel}
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

// ── GatedPlayerRows: show first N, blur the rest ──────────────────────────────

interface GatedPlayerRowsProps {
  hasAccess: boolean;
  children: React.ReactNode[]; // array of <tr> elements
  freeLimit?: number;
  totalCount?: number;
  upgradeMessage?: string;
}

export function GatedPlayerRows({
  hasAccess,
  children,
  freeLimit = 5,
  totalCount,
  upgradeMessage,
}: GatedPlayerRowsProps) {
  if (hasAccess) return <>{children}</>;

  const visible = children.slice(0, freeLimit);
  const hidden = children.slice(freeLimit);
  const hiddenCount = totalCount ? totalCount - freeLimit : hidden.length;
  const msg = upgradeMessage || `${hiddenCount} more players hidden — upgrade to see all`;

  return (
    <>
      {visible}
      {hidden.length > 0 && (
        <tr>
          <td colSpan={99} className="p-0">
            <div className="relative">
              {/* Blurred preview rows */}
              <div className="blur-[5px] select-none pointer-events-none opacity-50" aria-hidden>
                <table className="w-full">
                  <tbody>
                    {hidden.slice(0, 3)}
                  </tbody>
                </table>
              </div>
              {/* Upgrade CTA */}
              <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-transparent to-slate-950/80">
                <Link href="/pricing">
                  <button className="flex items-center gap-2 bg-slate-800/90 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs font-bold text-amber-400 hover:bg-slate-700/90 hover:border-amber-500/50 transition-all shadow-lg">
                    <Lock className="w-3.5 h-3.5" />
                    {msg}
                    <Crown className="w-3.5 h-3.5" />
                  </button>
                </Link>
              </div>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

// ── GatedLineupCards: show first N lineups, blur rest ─────────────────────────

interface GatedLineupCardsProps {
  hasAccess: boolean;
  children: React.ReactNode[];
  freeLimit?: number;
  totalGenerated?: number;
}

export function GatedLineupCards({
  hasAccess,
  children,
  freeLimit = 1,
  totalGenerated,
}: GatedLineupCardsProps) {
  if (hasAccess) return <>{children}</>;

  const visible = children.slice(0, freeLimit);
  const lockedCount = (totalGenerated || children.length) - freeLimit;

  return (
    <div className="space-y-4">
      {visible}

      {lockedCount > 0 && (
        <div className="relative">
          {/* Blurred previews */}
          <div className="space-y-3 blur-[8px] select-none pointer-events-none opacity-40" aria-hidden>
            {children.slice(1, 3)}
          </div>

          {/* Upgrade overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-slate-900/95 border border-amber-500/30 rounded-2xl p-6 text-center shadow-2xl max-w-xs mx-4">
              <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-4">
                <Crown className="w-6 h-6 text-amber-400" />
              </div>
              <p className="text-sm font-black text-white mb-1">
                {lockedCount} More Lineup{lockedCount > 1 ? "s" : ""} Ready
              </p>
              <p className="text-xs text-slate-400 mb-4">
                Upgrade to access all {totalGenerated || children.length} optimized lineups
              </p>
              <Link href="/pricing">
                <Button size="sm" className="bg-amber-500 hover:bg-amber-600 text-black font-black w-full">
                  <Crown className="w-3.5 h-3.5 mr-1.5" />
                  Unlock All Lineups
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── GatedStat: shows a blurred placeholder for a single stat ─────────────────

interface GatedStatProps {
  hasAccess: boolean;
  value: React.ReactNode;
  className?: string;
  placeholderWidth?: string;
}

export function GatedStat({ hasAccess, value, className = "", placeholderWidth = "w-12" }: GatedStatProps) {
  if (hasAccess) return <span className={className}>{value}</span>;
  return (
    <span className={`inline-flex items-center gap-1 ${className}`}>
      <span className={`${placeholderWidth} h-4 bg-slate-700/80 rounded blur-[2px] inline-block`} />
      <Lock className="w-3 h-3 text-slate-600" />
    </span>
  );
}

// ── GatedBadge: small inline badge showing a feature is premium ───────────────

export function GatedBadge({ label = "Champion" }: { label?: string }) {
  return (
    <Badge className="bg-amber-500/15 text-amber-400 border-amber-500/25 text-[9px] font-black px-1.5 py-0.5 gap-0.5">
      <Crown className="w-2.5 h-2.5" />
      {label}
    </Badge>
  );
}

// ── GatedOwnershipSection: wraps the ownership table with partial reveal ─────

interface GatedOwnershipSectionProps {
  hasAccess: boolean;
  children: React.ReactNode;
  playerCount: number;
  freeLimit?: number;
}

export function GatedOwnershipSection({
  hasAccess,
  children,
  playerCount,
  freeLimit = 5,
}: GatedOwnershipSectionProps) {
  if (hasAccess) return <>{children}</>;

  const hiddenCount = Math.max(0, playerCount - freeLimit);

  return (
    <div className="relative">
      {/* Partial fade at the bottom of visible rows */}
      <div className="relative overflow-hidden" style={{ maxHeight: `${freeLimit * 60}px` }}>
        {children}
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-slate-900 to-transparent pointer-events-none" />
      </div>

      {/* Upgrade CTA below */}
      <div className="mt-3 flex items-center justify-between bg-slate-800/60 border border-slate-700/50 rounded-xl px-4 py-3">
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 text-amber-400/70" />
          <span className="text-xs font-bold text-slate-300">
            +{hiddenCount} players hidden
          </span>
        </div>
        <Link href="/pricing">
          <button className="text-xs font-black text-amber-400 hover:text-amber-300 flex items-center gap-1.5 transition-colors">
            <Crown className="w-3.5 h-3.5" />
            See All
          </button>
        </Link>
      </div>
    </div>
  );
}

// ── Usage example for Optimizer.tsx integration ───────────────────────────────
//
// In ProOptimizer.tsx, wrap generated lineups:
//
//   import { GatedLineupCards } from "@/components/GatedContent";
//
//   <GatedLineupCards hasAccess={isPaidUser} totalGenerated={generatedLineups.length}>
//     {generatedLineups.map((lineup, idx) => (
//       <LineupCard key={idx} lineup={lineup} />
//     ))}
//   </GatedLineupCards>
//
// In OwnershipHeatmap.tsx, wrap position player list:
//
//   import { GatedOwnershipSection } from "@/components/GatedContent";
//
//   <GatedOwnershipSection hasAccess={hasAccess} playerCount={players.length}>
//     <div className="divide-y divide-slate-800/50">
//       {players.map(player => <PlayerRow key={player.id} player={player} />)}
//     </div>
//   </GatedOwnershipSection>
