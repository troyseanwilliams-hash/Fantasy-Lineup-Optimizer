// ============================================================
// FEATURE ROUTES — server/routes/features.ts
// Mount this in your main Express app:
//   import featureRoutes from "./routes/features";
//   app.use(featureRoutes);
//
// Assumes:
//   - req.user is populated by your session middleware
//   - db is your Drizzle instance
//   - You have Twilio + SendGrid env vars for SMS/email
// ============================================================

import { Router, Request, Response } from "express";
import { eq, and, desc, gte, sql } from "drizzle-orm";
import { db } from "../db";
import {
  lineups, lineupScores, alertDeliveries, notificationPreferences,
  performanceSnapshots, alerts, players, slates, winningLineups,
  playerHistory, users, subscriptions,
  type InsertLineupScore, type InsertAlertDelivery,
  type InsertNotificationPreferences,
} from "../../shared/schema";

const router = Router();

// ── Auth guard middleware ──────────────────────────────────────────────────────
function requireAuth(req: Request, res: Response, next: Function) {
  if (!req.user) return res.status(401).json({ message: "Unauthorized" });
  next();
}

function requirePaid(req: Request, res: Response, next: Function) {
  const tier = (req as any).userSubscription?.tier || "free";
  const isAdmin = (req.user as any)?.isAdmin === true;
  if (isAdmin || ["pro", "premium", "star"].includes(tier)) return next();
  return res.status(403).json({ message: "This feature requires a paid subscription." });
}

// ============================================================
// 1. LIVE LINEUP SCORE TRACKER
// ============================================================

// GET /api/lineup-scores — get live scores for all user lineups on a slate
router.get("/api/lineup-scores", requireAuth, async (req, res) => {
  try {
    const userId = (req.user as any).id;
    const { slateId } = req.query;

    const query = db
      .select({
        lineupId: lineupScores.lineupId,
        lineupName: lineups.name,
        sport: lineupScores.sport,
        playerScores: lineupScores.playerScores,
        totalLivePoints: lineupScores.totalLivePoints,
        totalProjectedPoints: lineupScores.totalProjectedPoints,
        contestRank: lineupScores.contestRank,
        contestTotalEntries: lineupScores.contestTotalEntries,
        contestPrize: lineupScores.contestPrize,
        scoringStatus: lineupScores.scoringStatus,
        lastUpdatedAt: lineupScores.lastUpdatedAt,
        dkContestName: lineups.dkContestName,
        dkEntryId: lineups.dkEntryId,
      })
      .from(lineupScores)
      .innerJoin(lineups, eq(lineupScores.lineupId, lineups.id))
      .where(
        slateId
          ? and(eq(lineupScores.userId, userId), eq(lineupScores.slateId, Number(slateId)))
          : eq(lineupScores.userId, userId)
      )
      .orderBy(desc(lineupScores.lastUpdatedAt));

    const scores = await query;
    return res.json(scores);
  } catch (err: any) {
    console.error("[lineup-scores GET]", err);
    return res.status(500).json({ message: "Failed to fetch lineup scores" });
  }
});

// POST /api/lineup-scores/refresh — trigger a score refresh for a slate
// In production this would call the DK Live Scoring API
router.post("/api/lineup-scores/refresh", requireAuth, async (req, res) => {
  try {
    const userId = (req.user as any).id;
    const { slateId } = req.body;
    if (!slateId) return res.status(400).json({ message: "slateId required" });

    // Fetch user's lineups for this slate that have DK entry IDs
    const userLineups = await db
      .select()
      .from(lineups)
      .where(and(eq(lineups.userId, userId), eq(lineups.slateId, slateId)));

    if (userLineups.length === 0) {
      return res.json({ updated: 0, message: "No lineups found for this slate" });
    }

    // Get players for this slate to resolve scores
    const slatePlayerData = await db
      .select()
      .from(players)
      .where(eq(players.slateId, slateId));

    const playerMap = new Map(slatePlayerData.map(p => [p.id, p]));

    // In production: call DK Live Scoring API here using lineup.dkEntryId
    // For now, derive best-effort live scores from player history / actual points
    const updates: InsertLineupScore[] = [];

    for (const lineup of userLineups) {
      const playerScores = (lineup.playerIds || []).map((pid: number) => {
        const p = playerMap.get(pid);
        return {
          playerId: pid,
          playerName: p?.name || `Player #${pid}`,
          position: p?.position || "",
          livePoints: 0, // populated from DK API in production
          projectedPoints: Number(p?.projectedPoints || 0),
          isPlaying: false,
          isComplete: false,
          gameStatus: "pregame" as const,
        };
      });

      const existing = await db
        .select()
        .from(lineupScores)
        .where(eq(lineupScores.lineupId, lineup.id))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(lineupScores)
          .set({ playerScores, lastUpdatedAt: new Date() })
          .where(eq(lineupScores.id, existing[0].id));
      } else {
        updates.push({
          lineupId: lineup.id,
          userId,
          sport: lineup.sport,
          slateId,
          playerScores,
          totalLivePoints: "0",
          totalProjectedPoints: String(lineup.totalProjectedPoints),
          scoringStatus: "pregame",
          lastUpdatedAt: new Date(),
        });
      }
    }

    if (updates.length > 0) {
      await db.insert(lineupScores).values(updates);
    }

    return res.json({ updated: userLineups.length });
  } catch (err: any) {
    console.error("[lineup-scores/refresh]", err);
    return res.status(500).json({ message: "Failed to refresh scores" });
  }
});

// PATCH /api/lineup-scores/:lineupId — update live score (called by scoring worker)
router.patch("/api/lineup-scores/:lineupId", requireAuth, async (req, res) => {
  try {
    const { lineupId } = req.params;
    const { playerScores, totalLivePoints, scoringStatus, contestRank, contestTotalEntries, contestPrize } = req.body;

    await db
      .update(lineupScores)
      .set({
        playerScores,
        totalLivePoints: String(totalLivePoints),
        scoringStatus,
        contestRank,
        contestTotalEntries,
        contestPrize,
        lastUpdatedAt: new Date(),
      })
      .where(eq(lineupScores.lineupId, Number(lineupId)));

    return res.json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ message: "Failed to update score" });
  }
});

// ============================================================
// 2. INJURY ALERT SMS/EMAIL
// ============================================================

// GET /api/notification-preferences — get user's notification settings
router.get("/api/notification-preferences", requireAuth, async (req, res) => {
  try {
    const userId = (req.user as any).id;
    const prefs = await db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId))
      .limit(1);

    if (prefs.length === 0) {
      // Return defaults if not configured yet
      return res.json({
        smsEnabled: false,
        emailEnabled: true,
        pushEnabled: false,
        injuryAlerts: true,
        lineupScoringAlerts: true,
        slateStartAlerts: false,
        preGameAlertMinutes: 30,
      });
    }
    return res.json(prefs[0]);
  } catch (err: any) {
    return res.status(500).json({ message: "Failed to fetch preferences" });
  }
});

// PUT /api/notification-preferences — upsert user's notification settings
router.put("/api/notification-preferences", requireAuth, async (req, res) => {
  try {
    const userId = (req.user as any).id;
    const {
      smsEnabled, emailEnabled, pushEnabled,
      injuryAlerts, lineupScoringAlerts, slateStartAlerts,
      preGameAlertMinutes,
    } = req.body;

    const existing = await db
      .select({ id: notificationPreferences.id })
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId))
      .limit(1);

    const data: InsertNotificationPreferences = {
      userId,
      smsEnabled: smsEnabled ?? false,
      emailEnabled: emailEnabled ?? true,
      pushEnabled: pushEnabled ?? false,
      injuryAlerts: injuryAlerts ?? true,
      lineupScoringAlerts: lineupScoringAlerts ?? true,
      slateStartAlerts: slateStartAlerts ?? false,
      preGameAlertMinutes: preGameAlertMinutes ?? 30,
    };

    if (existing.length > 0) {
      await db
        .update(notificationPreferences)
        .set({ ...data, updatedAt: new Date() })
        .where(eq(notificationPreferences.userId, userId));
    } else {
      await db.insert(notificationPreferences).values(data);
    }

    return res.json(data);
  } catch (err: any) {
    return res.status(500).json({ message: "Failed to save preferences" });
  }
});

// POST /api/alerts/deliver — internal endpoint called by alert worker
// Sends pending alerts via SMS/email for a user
router.post("/api/alerts/deliver", async (req, res) => {
  // In production, secure this with an internal API key check
  const { userId, alertId } = req.body;
  if (!userId || !alertId) return res.status(400).json({ message: "userId and alertId required" });

  try {
    const [alert] = await db.select().from(alerts).where(eq(alerts.id, alertId)).limit(1);
    if (!alert) return res.status(404).json({ message: "Alert not found" });

    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!user) return res.status(404).json({ message: "User not found" });

    const [prefs] = await db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId))
      .limit(1);

    const results: { channel: string; status: string; externalId?: string; error?: string }[] = [];

    // SMS delivery via Twilio
    if (prefs?.smsEnabled && user.phone && user.smsConsent) {
      try {
        // In production:
        // const twilioClient = require("twilio")(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
        // const msg = await twilioClient.messages.create({
        //   body: `EliteLineup Alert: ${alert.title}\n${alert.message}`,
        //   from: process.env.TWILIO_PHONE_NUMBER,
        //   to: user.phone,
        // });
        // const externalId = msg.sid;

        // Stub: log the delivery
        console.log(`[AlertDelivery] SMS to ${user.phone}: ${alert.title}`);
        const externalId = `sms_stub_${Date.now()}`;

        await db.insert(alertDeliveries).values({
          alertId,
          userId,
          channel: "sms",
          status: "sent",
          externalId,
          sentAt: new Date(),
        });
        results.push({ channel: "sms", status: "sent", externalId });
      } catch (smsErr: any) {
        await db.insert(alertDeliveries).values({
          alertId,
          userId,
          channel: "sms",
          status: "failed",
          errorMessage: smsErr.message,
        });
        results.push({ channel: "sms", status: "failed", error: smsErr.message });
      }
    }

    // Email delivery via SendGrid
    if (prefs?.emailEnabled && user.email && user.emailConsent) {
      try {
        // In production:
        // const sgMail = require("@sendgrid/mail");
        // sgMail.setApiKey(process.env.SENDGRID_API_KEY);
        // const msg = await sgMail.send({
        //   to: user.email,
        //   from: "alerts@elitelineup.com",
        //   subject: `EliteLineup Alert: ${alert.title}`,
        //   text: alert.message,
        //   html: `<strong>${alert.title}</strong><p>${alert.message}</p>`,
        // });

        console.log(`[AlertDelivery] Email to ${user.email}: ${alert.title}`);
        const externalId = `email_stub_${Date.now()}`;

        await db.insert(alertDeliveries).values({
          alertId,
          userId,
          channel: "email",
          status: "sent",
          externalId,
          sentAt: new Date(),
        });
        results.push({ channel: "email", status: "sent", externalId });
      } catch (emailErr: any) {
        await db.insert(alertDeliveries).values({
          alertId,
          userId,
          channel: "email",
          status: "failed",
          errorMessage: emailErr.message,
        });
        results.push({ channel: "email", status: "failed", error: emailErr.message });
      }
    }

    return res.json({ alertId, userId, deliveries: results });
  } catch (err: any) {
    console.error("[alerts/deliver]", err);
    return res.status(500).json({ message: "Delivery failed" });
  }
});

// GET /api/alerts — user's alerts (already in routes.ts, adding delivery status here)
router.get("/api/alerts/with-delivery", requireAuth, async (req, res) => {
  try {
    const userId = (req.user as any).id;
    const userAlerts = await db
      .select({
        id: alerts.id,
        lineupId: alerts.lineupId,
        playerId: alerts.playerId,
        playerName: alerts.playerName,
        sport: alerts.sport,
        type: alerts.type,
        title: alerts.title,
        message: alerts.message,
        severity: alerts.severity,
        isRead: alerts.isRead,
        createdAt: alerts.createdAt,
      })
      .from(alerts)
      .where(eq(alerts.userId, userId))
      .orderBy(desc(alerts.createdAt))
      .limit(50);

    // Attach delivery status for each alert
    const alertIds = userAlerts.map(a => a.id);
    const deliveries = alertIds.length > 0
      ? await db
          .select()
          .from(alertDeliveries)
          .where(eq(alertDeliveries.userId, userId))
      : [];

    const deliveryMap = new Map<number, typeof deliveries>();
    for (const d of deliveries) {
      const arr = deliveryMap.get(d.alertId) || [];
      arr.push(d);
      deliveryMap.set(d.alertId, arr);
    }

    return res.json(userAlerts.map(a => ({
      ...a,
      deliveries: deliveryMap.get(a.id) || [],
    })));
  } catch (err: any) {
    return res.status(500).json({ message: "Failed to fetch alerts" });
  }
});

// ============================================================
// 3. PERFORMANCE DASHBOARD
// ============================================================

// GET /api/performance — user's performance summary across all sports
router.get("/api/performance", requireAuth, async (req, res) => {
  try {
    const userId = (req.user as any).id;
    const { sport, limit = 30 } = req.query;

    const snapshots = await db
      .select()
      .from(performanceSnapshots)
      .where(
        sport
          ? and(eq(performanceSnapshots.userId, userId), eq(performanceSnapshots.sport, String(sport)))
          : eq(performanceSnapshots.userId, userId)
      )
      .orderBy(desc(performanceSnapshots.slateDate))
      .limit(Number(limit));

    // Compute aggregate stats
    const snapshotsWithActuals = snapshots.filter(s => s.avgUserScore !== null);
    const totalSlates = snapshots.length;
    const avgAccuracy = snapshotsWithActuals.length > 0
      ? snapshotsWithActuals.reduce((sum, s) => sum + Number(s.avgProjectionAccuracy || 0), 0) / snapshotsWithActuals.length
      : null;
    const avgVsOptimal = snapshotsWithActuals.length > 0
      ? snapshotsWithActuals.reduce((sum, s) => sum + Number(s.vsOptimalPct || 0), 0) / snapshotsWithActuals.length
      : null;
    const avgVsField = snapshotsWithActuals.length > 0
      ? snapshotsWithActuals.reduce((sum, s) => sum + Number(s.vsFieldPct || 0), 0) / snapshotsWithActuals.length
      : null;
    const bestSlate = snapshotsWithActuals.length > 0
      ? snapshotsWithActuals.reduce((best, s) =>
          Number(s.vsOptimalPct || 0) > Number(best.vsOptimalPct || 0) ? s : best
        )
      : null;

    return res.json({
      snapshots,
      summary: {
        totalSlates,
        avgAccuracy: avgAccuracy ? Math.round(avgAccuracy * 10) / 10 : null,
        avgVsOptimal: avgVsOptimal ? Math.round(avgVsOptimal * 10) / 10 : null,
        avgVsField: avgVsField ? Math.round(avgVsField * 10) / 10 : null,
        bestSlate,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ message: "Failed to fetch performance data" });
  }
});

// POST /api/performance/compute — compute and store performance snapshot for a user/sport/date
// Called by nightly analysis worker after actual points are fetched
router.post("/api/performance/compute", async (req, res) => {
  const { userId, sport, slateDate, slateId } = req.body;
  if (!userId || !sport || !slateDate) {
    return res.status(400).json({ message: "userId, sport, and slateDate required" });
  }

  try {
    // Get user's lineups for this slate
    const userLineupData = await db
      .select()
      .from(lineups)
      .where(
        slateId
          ? and(eq(lineups.userId, userId), eq(lineups.slateId, slateId))
          : and(eq(lineups.userId, userId), eq(lineups.sport, sport))
      );

    if (userLineupData.length === 0) {
      return res.json({ skipped: true, reason: "No lineups found" });
    }

    // Get optimal lineup for comparison
    const [optimalLineup] = await db
      .select()
      .from(winningLineups)
      .where(and(eq(winningLineups.sport, sport), eq(winningLineups.slateDate, slateDate)))
      .limit(1);

    const optimalScore = optimalLineup ? Number(optimalLineup.totalActualPoints) : null;

    // Get player history for this slate to compute actual scores
    const historyRecords = await db
      .select()
      .from(playerHistory)
      .where(and(eq(playerHistory.sport, sport), eq(playerHistory.slateDate, slateDate)));

    const actualPointsMap = new Map(historyRecords.map(h => [h.playerName, Number(h.actualPoints || 0)]));

    // Compute per-lineup scores
    const lineupActualScores: number[] = [];
    let totalProjectionAccuracy = 0;
    let projectionAccuracyCount = 0;

    for (const lineup of userLineupData) {
      const snapshot = (lineup.playerSnapshot as any[]) || [];
      if (snapshot.length === 0) continue;

      let lineupActual = 0;
      for (const p of snapshot) {
        const actual = actualPointsMap.get(p.name) || 0;
        const projected = Number(p.projectedPoints || 0);
        lineupActual += actual;
        if (projected > 0 && actual > 0) {
          totalProjectionAccuracy += actual / projected;
          projectionAccuracyCount++;
        }
      }
      lineupActualScores.push(lineupActual);
    }

    if (lineupActualScores.length === 0) {
      return res.json({ skipped: true, reason: "No actual scores available yet" });
    }

    const avgUserScore = lineupActualScores.reduce((a, b) => a + b, 0) / lineupActualScores.length;
    const bestUserScore = Math.max(...lineupActualScores);
    const avgProjectionAccuracy = projectionAccuracyCount > 0
      ? totalProjectionAccuracy / projectionAccuracyCount
      : null;

    // Field average: use winning lineup insights if available
    const fieldAvgScore = optimalLineup?.insights
      ? (optimalLineup.insights as any).poolAvgActual || null
      : null;

    const vsOptimalPct = optimalScore && optimalScore > 0
      ? (bestUserScore / optimalScore) * 100
      : null;
    const vsFieldPct = fieldAvgScore && fieldAvgScore > 0
      ? (avgUserScore / fieldAvgScore) * 100
      : null;

    const snapshotData = {
      userId,
      sport,
      slateDate,
      slateId: slateId || null,
      lineupCount: userLineupData.length,
      avgUserScore: String(Math.round(avgUserScore * 100) / 100),
      bestUserScore: String(Math.round(bestUserScore * 100) / 100),
      optimalScore: optimalScore ? String(optimalScore) : null,
      fieldAvgScore: fieldAvgScore ? String(fieldAvgScore) : null,
      avgProjectionAccuracy: avgProjectionAccuracy ? String(Math.round(avgProjectionAccuracy * 1000) / 1000) : null,
      vsOptimalPct: vsOptimalPct ? String(Math.round(vsOptimalPct * 10) / 10) : null,
      vsFieldPct: vsFieldPct ? String(Math.round(vsFieldPct * 10) / 10) : null,
    };

    // Upsert — replace existing snapshot if same user/sport/date
    const existing = await db
      .select({ id: performanceSnapshots.id })
      .from(performanceSnapshots)
      .where(and(
        eq(performanceSnapshots.userId, userId),
        eq(performanceSnapshots.sport, sport),
        eq(performanceSnapshots.slateDate, slateDate)
      ))
      .limit(1);

    if (existing.length > 0) {
      await db.update(performanceSnapshots).set(snapshotData).where(eq(performanceSnapshots.id, existing[0].id));
    } else {
      await db.insert(performanceSnapshots).values(snapshotData);
    }

    return res.json({ success: true, snapshot: snapshotData });
  } catch (err: any) {
    console.error("[performance/compute]", err);
    return res.status(500).json({ message: "Failed to compute performance" });
  }
});

// ============================================================
// 4. TRACK RECORD PAGE
// ============================================================

// GET /api/track-record — public endpoint showing algorithm accuracy
// Returns winning lineup history with projection vs actual comparisons
router.get("/api/track-record", async (req, res) => {
  try {
    const { sport, limit = 20 } = req.query;

    const records = await db
      .select()
      .from(winningLineups)
      .where(sport ? eq(winningLineups.sport, String(sport)) : undefined)
      .orderBy(desc(winningLineups.slateDate))
      .limit(Number(limit));

    // Compute aggregate accuracy stats
    const recordsWithInsights = records.filter(r => r.insights);
    const avgAccuracy = recordsWithInsights.length > 0
      ? recordsWithInsights.reduce((sum, r) => {
          const insights = r.insights as any;
          return sum + (insights?.avgProjectionRatio || 1);
        }, 0) / recordsWithInsights.length
      : null;

    const sportBreakdown: Record<string, {
      count: number;
      avgScore: number;
      avgAccuracy: number;
      avgSalaryUtil: number;
    }> = {};

    for (const r of recordsWithInsights) {
      const insights = r.insights as any;
      if (!sportBreakdown[r.sport]) {
        sportBreakdown[r.sport] = { count: 0, avgScore: 0, avgAccuracy: 0, avgSalaryUtil: 0 };
      }
      const s = sportBreakdown[r.sport];
      s.count++;
      s.avgScore += Number(r.totalActualPoints);
      s.avgAccuracy += insights?.avgProjectionRatio || 1;
      s.avgSalaryUtil += insights?.salaryUtilization || 0;
    }

    for (const sport of Object.keys(sportBreakdown)) {
      const s = sportBreakdown[sport];
      s.avgScore = Math.round((s.avgScore / s.count) * 10) / 10;
      s.avgAccuracy = Math.round((s.avgAccuracy / s.count) * 1000) / 10; // as %
      s.avgSalaryUtil = Math.round((s.avgSalaryUtil / s.count) * 10) / 10;
    }

    return res.json({
      records: records.map(r => ({
        id: r.id,
        sport: r.sport,
        slateDate: r.slateDate,
        totalActualPoints: Number(r.totalActualPoints),
        totalSalary: r.totalSalary,
        salaryCap: r.salaryCap,
        salaryUtilization: r.salaryCap > 0
          ? Math.round((r.totalSalary / r.salaryCap) * 1000) / 10
          : 0,
        playerData: r.playerData,
        // Safe subset of insights for public display
        avgProjectionRatio: (r.insights as any)?.avgProjectionRatio || null,
        boostHitRate: (r.insights as any)?.boostHitRate || null,
        outperformanceMultiple: (r.insights as any)?.outperformanceMultiple || null,
        poolAvgActual: (r.insights as any)?.poolAvgActual || null,
      })),
      summary: {
        totalSlatesAnalyzed: records.length,
        avgProjectionAccuracy: avgAccuracy ? Math.round(avgAccuracy * 1000) / 10 : null,
        sportBreakdown,
      },
    });
  } catch (err: any) {
    console.error("[track-record GET]", err);
    return res.status(500).json({ message: "Failed to fetch track record" });
  }
});

// ============================================================
// 5. SUBSCRIPTION GATING — teaser endpoint
// Returns gated content marker so frontend knows what to blur
// ============================================================

// GET /api/content-access — returns what content tiers the user can see
router.get("/api/content-access", requireAuth, async (req, res) => {
  try {
    const userId = (req.user as any).id;
    const isAdmin = (req.user as any)?.isAdmin === true;

    const [sub] = await db
      .select({ tier: subscriptions.tier, status: subscriptions.status })
      .from(subscriptions)
      .where(eq(subscriptions.userId, userId))
      .limit(1);

    const tier = sub?.tier || "free";
    const status = sub?.status || "active";
    const isPaid = isAdmin || ["pro", "premium", "star"].includes(tier);
    const isActive = status === "active" || status === "trialing";

    return res.json({
      tier,
      status,
      isAdmin,
      isPaid: isPaid && isActive,
      // Feature-level access flags
      access: {
        // Free: 1 optimizer lineup (shown, rest blurred)
        optimizerLineupLimit: isAdmin ? 150 : tier === "star" ? 20 : tier === "pro" ? 20 : 1,
        // Free: see top 5 players per position in ownership, rest blurred
        ownershipPlayerLimit: isPaid && isActive ? null : 5,
        // Free: no performance dashboard
        performanceDashboard: isPaid && isActive,
        // Free: no live scoring
        liveScoring: isPaid && isActive,
        // Free: no pro optimizer
        proOptimizer: isPaid && isActive,
        // Track record: public
        trackRecord: true,
        // Injury alerts: paid only
        injuryAlerts: isPaid && isActive,
        // Notification preferences: paid only
        notificationPreferences: isPaid && isActive,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ message: "Failed to check access" });
  }
});

export default router;
