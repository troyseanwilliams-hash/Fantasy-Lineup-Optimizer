import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  Zap, RefreshCw, TrendingUp, TrendingDown, Trophy,
  Crown, Lock, Loader2, Activity, CircleDot, CheckCircle2,
  Clock, DollarSign, Target, ChevronDown, ChevronUp
} from "lucide-react";
import type { Slate } from "@shared/schema";

interface PlayerScore {
  playerId: number;
  playerName: string;
  position: string;
  livePoints: number;
  projectedPoints: number;
  isPlaying: boolean;
  isComplete: boolean;
  gameStatus: "pregame" | "live" | "final";
}

interface LineupScoreData {
  lineupId: number;
  lineupName: string | null;
  sport: string;
  playerScores: PlayerScore[];
  totalLivePoints: string;
  totalProjectedPoints: string;
  contestRank: number | null;
  contestTotalEntries: number | null;
  contestPrize: string | null;
  scoringStatus: "pregame" | "live" | "final";
  lastUpdatedAt: string;
  dkContestName: string | null;
  dkEntryId: string | null;
}

function StatusPip({ status }: { status: "pregame" | "live" | "final" }) {
  if (status === "live") return (
    <span className="flex items-center gap-1.5">
      <span className="relative flex h-2 w-2">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
      </span>
      <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Live</span>
    </span>
  );
  if (status === "final") return (
    <span className="flex items-center gap-1.5">
      <CheckCircle2 className="w-3 h-3 text-slate-400" />
      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Final</span>
    </span>
  );
  return (
    <span className="flex items-center gap-1.5">
      <Clock className="w-3 h-3 text-slate-500" />
      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Pre-Game</span>
    </span>
  );
}

function ScoreBar({ live, projected }: { live: number; projected: number }) {
  const pct = projected > 0 ? Math.min(100, (live / projected) * 100) : 0;
  const color = pct >= 100 ? "bg-emerald-500" : pct >= 75 ? "bg-amber-500" : pct >= 50 ? "bg-orange-500" : "bg-slate-600";
  return (
    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
      <div className={`h-full rounded-full transition-all duration-500 ${color}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

function LineupScoreCard({ data, defaultOpen = false }: { data: LineupScoreData; defaultOpen?: boolean }) {
  const [expanded, setExpanded] = useState(defaultOpen);
  const liveTotal = Number(data.totalLivePoints);
  const projTotal = Number(data.totalProjectedPoints);
  const pctOfProj = projTotal > 0 ? Math.round((liveTotal / projTotal) * 100) : 0;
  const isAhead = liveTotal > projTotal * 0.5;

  return (
    <Card className="bg-slate-900/80 border-slate-700/60 overflow-hidden">
      {/* Header */}
      <div
        className="px-5 py-4 flex items-center gap-4 cursor-pointer hover:bg-slate-800/30 transition-colors"
        onClick={() => setExpanded(e => !e)}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sm font-black text-white truncate">
              {data.lineupName || `Lineup #${data.lineupId}`}
            </span>
            <StatusPip status={data.scoringStatus} />
          </div>
          {data.dkContestName && (
            <p className="text-[11px] text-slate-500 font-bold truncate">{data.dkContestName}</p>
          )}
        </div>

        {/* Live score */}
        <div className="text-right shrink-0">
          <p className={`text-2xl font-black tabular-nums ${
            data.scoringStatus === "live" ? "text-emerald-400" :
            data.scoringStatus === "final" ? "text-white" : "text-slate-500"
          }`}>
            {liveTotal > 0 ? liveTotal.toFixed(1) : "—"}
          </p>
          <p className="text-[10px] text-slate-500 font-bold">
            proj {projTotal.toFixed(1)}
          </p>
        </div>

        {/* Contest rank */}
        {data.contestRank && (
          <div className="text-right shrink-0 pl-3 border-l border-slate-700/50">
            <div className="flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-sm font-black text-amber-400">#{data.contestRank}</span>
            </div>
            <p className="text-[10px] text-slate-500 font-bold">of {data.contestTotalEntries?.toLocaleString()}</p>
          </div>
        )}

        {expanded ? <ChevronUp className="w-4 h-4 text-slate-500 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />}
      </div>

      {/* Progress bar */}
      {data.scoringStatus !== "pregame" && (
        <div className="px-5 pb-1">
          <ScoreBar live={liveTotal} projected={projTotal} />
          <p className="text-[10px] text-slate-500 mt-1">{pctOfProj}% of projected</p>
        </div>
      )}

      {/* Expanded player breakdown */}
      {expanded && (
        <div className="border-t border-slate-800/50">
          <div className="divide-y divide-slate-800/30">
            {data.playerScores.map(ps => {
              const diff = ps.livePoints - ps.projectedPoints;
              return (
                <div key={ps.playerId} className="px-5 py-2.5 flex items-center gap-3">
                  <span className="text-[10px] font-black text-slate-500 w-8 shrink-0">{ps.position}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">{ps.playerName}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      {ps.gameStatus === "live" && (
                        <span className="text-[9px] font-black text-emerald-400 uppercase">●  Playing</span>
                      )}
                      {ps.gameStatus === "final" && (
                        <span className="text-[9px] font-black text-slate-500 uppercase">Final</span>
                      )}
                      {ps.gameStatus === "pregame" && (
                        <span className="text-[9px] font-black text-slate-600 uppercase">Pre-game</span>
                      )}
                    </div>
                  </div>
                  <div className="text-right shrink-0 w-24">
                    <div className="flex items-center justify-end gap-2">
                      <span className="text-xs font-black text-white tabular-nums">
                        {ps.livePoints > 0 ? ps.livePoints.toFixed(1) : "—"}
                      </span>
                      {ps.livePoints > 0 && (
                        <span className={`text-[10px] font-bold tabular-nums ${
                          diff > 0 ? "text-emerald-400" : diff < 0 ? "text-red-400" : "text-slate-500"
                        }`}>
                          {diff > 0 ? "+" : ""}{diff.toFixed(1)}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-500">proj {ps.projectedPoints.toFixed(1)}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Prize if won */}
          {data.contestPrize && (
            <div className="px-5 py-3 bg-amber-500/5 border-t border-amber-500/20">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span className="text-sm font-bold text-amber-400">Prize: {data.contestPrize}</span>
              </div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}

export default function LiveScoreTracker() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const isAdmin = (user as any)?.isAdmin === true;

  const { data: slates } = useQuery<Slate[]>({ queryKey: ["/api/slates"] });
  const { data: subscription } = useQuery<{ tier: string }>({ queryKey: ["/api/subscription"], enabled: !!user });

  const tier = subscription?.tier || "free";
  const hasAccess = isAdmin || ["pro", "premium", "star"].includes(tier);

  const activeSlates = slates?.filter(s => {
    const start = new Date(s.startTime);
    const now = new Date();
    const hoursAgo = (now.getTime() - start.getTime()) / (1000 * 60 * 60);
    return hoursAgo >= 0 && hoursAgo < 24; // slates that started in the last 24h
  }) || [];

  const [selectedSlateId, setSelectedSlateId] = useState<number | null>(null);
  const activeSlateId = selectedSlateId || activeSlates[0]?.id || null;

  const { data: scores, isLoading, dataUpdatedAt } = useQuery<LineupScoreData[]>({
    queryKey: ["/api/lineup-scores", activeSlateId],
    queryFn: async () => {
      const url = activeSlateId ? `/api/lineup-scores?slateId=${activeSlateId}` : "/api/lineup-scores";
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to load scores");
      return res.json();
    },
    enabled: !!user && hasAccess,
    refetchInterval: 60000, // poll every minute during live games
  });

  const refreshMutation = useMutation({
    mutationFn: async () => {
      if (!activeSlateId) return;
      await apiRequest("POST", "/api/lineup-scores/refresh", { slateId: activeSlateId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lineup-scores"] });
    },
  });

  const hasLive = scores?.some(s => s.scoringStatus === "live");
  const lastUpdated = dataUpdatedAt ? new Date(dataUpdatedAt).toLocaleTimeString() : null;

  if (!hasAccess) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center p-6">
        <Card className="bg-slate-900 border-amber-500/30 p-8 max-w-md text-center">
          <div className="w-16 h-16 rounded-full bg-amber-500/10 flex items-center justify-center mx-auto mb-5">
            <Activity className="w-8 h-8 text-amber-400" />
          </div>
          <Crown className="w-6 h-6 text-amber-400 mx-auto mb-3" />
          <h2 className="text-xl font-black text-white mb-2">Live Score Tracker</h2>
          <p className="text-sm text-slate-400 mb-6">Track your lineup scores in real time, see how you're ranking in your contests, and watch your players perform live.</p>
          <Link href="/pricing">
            <Button className="bg-amber-500 hover:bg-amber-600 text-black font-black w-full">
              <Crown className="w-4 h-4 mr-2" /> Unlock Live Scoring
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/60 px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Activity className="w-6 h-6 text-emerald-400" />
              {hasLive && (
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
              )}
            </div>
            <div>
              <h1 className="text-xl font-black text-white">Live Score Tracker</h1>
              {lastUpdated && (
                <p className="text-[11px] text-slate-500">Updated {lastUpdated}</p>
              )}
            </div>
            {hasLive && (
              <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-[10px] font-black animate-pulse">
                LIVE
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Slate selector */}
            {activeSlates.length > 1 && (
              <select
                className="bg-slate-800 border border-slate-700 text-white text-xs font-bold rounded-lg px-3 py-2"
                value={activeSlateId || ""}
                onChange={e => setSelectedSlateId(Number(e.target.value))}
              >
                {activeSlates.map(s => (
                  <option key={s.id} value={s.id}>{s.sport} — {new Date(s.startTime).toLocaleDateString()}</option>
                ))}
              </select>
            )}

            <Button
              variant="outline"
              size="sm"
              onClick={() => refreshMutation.mutate()}
              disabled={refreshMutation.isPending}
              className="border-slate-700 text-slate-300 text-xs font-bold"
            >
              {refreshMutation.isPending
                ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                : <RefreshCw className="w-3.5 h-3.5" />
              }
              <span className="ml-1.5 hidden sm:inline">Refresh</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
          </div>
        ) : !scores || scores.length === 0 ? (
          <Card className="bg-slate-900 border-slate-700 p-12 text-center">
            <Target className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-white mb-2">No Active Lineups</h3>
            <p className="text-sm text-slate-400 mb-6">
              {activeSlates.length === 0
                ? "No slates are currently active. Scores appear here once games start."
                : "Save lineups in the Optimizer to track their live scores here."}
            </p>
            <Link href="/optimizer">
              <Button className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold">
                <Zap className="w-4 h-4 mr-2" /> Build Lineups
              </Button>
            </Link>
          </Card>
        ) : (
          <div className="space-y-4">
            {/* Summary bar */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              {[
                { label: "Lineups", value: scores.length, icon: <CircleDot className="w-4 h-4 text-slate-400" /> },
                {
                  label: "Best Score",
                  value: Math.max(...scores.map(s => Number(s.totalLivePoints))).toFixed(1),
                  icon: <TrendingUp className="w-4 h-4 text-emerald-400" />,
                },
                {
                  label: "Live",
                  value: scores.filter(s => s.scoringStatus === "live").length,
                  icon: <Activity className="w-4 h-4 text-emerald-400" />,
                },
              ].map(stat => (
                <Card key={stat.label} className="bg-slate-900/60 border-slate-700/50 p-4 text-center">
                  <div className="flex items-center justify-center gap-1.5 mb-1">{stat.icon}</div>
                  <p className="text-xl font-black text-white">{stat.value}</p>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{stat.label}</p>
                </Card>
              ))}
            </div>

            {scores.map((s, idx) => (
              <LineupScoreCard key={s.lineupId} data={s} defaultOpen={idx === 0} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
