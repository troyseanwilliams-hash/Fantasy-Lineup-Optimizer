# Feature Integration Guide
# EliteLineup — 5 New Features
# ============================================================

## Files Delivered

| File | Purpose |
|------|---------|
| `schema-additions.ts` | New DB tables — append to shared/schema.ts |
| `feature-routes.ts` | All backend routes — mount in Express |
| `LiveScoreTracker.tsx` | New page: /live-scores |
| `NotificationPreferences.tsx` | New page: /notifications |
| `GatedContent.tsx` | Shared component — blur/teaser pattern |
| `PerformanceDashboard.tsx` | New page: /performance |
| `TrackRecord.tsx` | New page: /track-record (public) |

---

## Step 1 — Database

Append the contents of `schema-additions.ts` to `shared/schema.ts`, then run:

```bash
npx drizzle-kit generate
npx drizzle-kit migrate
```

Also run the trigger SQL from the migration note at the bottom of schema-additions.ts.

---

## Step 2 — Backend Routes

Mount the feature routes in your main Express app (server/index.ts or server/routes.ts):

```ts
import featureRoutes from "./routes/features";
app.use(featureRoutes);
```

The routes assume:
- `req.user` is populated by your session middleware
- `req.userSubscription` is populated (or check subscription in each route — already handled)
- `db` is your Drizzle instance, imported from `../db`

For SMS/email: uncomment the Twilio/SendGrid blocks in `/api/alerts/deliver` and set:
  - `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_PHONE_NUMBER`
  - `SENDGRID_API_KEY`

---

## Step 3 — Routes (Frontend Router)

Add these routes to your router (client/src/App.tsx or wherever you define routes):

```tsx
import LiveScoreTracker from "@/pages/LiveScoreTracker";
import NotificationPreferences from "@/pages/NotificationPreferences";
import PerformanceDashboard from "@/pages/PerformanceDashboard";
import TrackRecord from "@/pages/TrackRecord";

// In your route definitions:
<Route path="/live-scores" component={LiveScoreTracker} />
<Route path="/notifications" component={NotificationPreferences} />
<Route path="/performance" component={PerformanceDashboard} />
<Route path="/track-record" component={TrackRecord} />  {/* public — no auth guard */}
```

---

## Step 4 — Blur/Teaser Integration

### In ProOptimizer.tsx (lineup cards):

```tsx
import { GatedLineupCards } from "@/components/GatedContent";

// Replace the current lineups map with:
<GatedLineupCards hasAccess={hasPaidAccess} totalGenerated={generatedLineups.length}>
  {generatedLineups.map((lineup, idx) => (
    <LineupCard key={idx} lineup={lineup} index={idx} />
  ))}
</GatedLineupCards>
```

### In OwnershipHeatmap.tsx (player list per position):

```tsx
import { GatedOwnershipSection } from "@/components/GatedContent";

// Wrap each position card's player list:
<GatedOwnershipSection hasAccess={hasAccess} playerCount={players.length} freeLimit={5}>
  <div className="divide-y divide-slate-800/50">
    {players.map(player => (
      <PlayerRow key={player.id} player={player} />
    ))}
  </div>
</GatedOwnershipSection>
```

### For individual stats (e.g. projected ownership for free users):

```tsx
import { GatedStat } from "@/components/GatedContent";

<GatedStat hasAccess={hasAccess} value={`${player.ownershipProjection.toFixed(1)}%`} />
```

---

## Step 5 — Navigation

Add links to the new pages in your sidebar/nav. Suggested additions:

```tsx
// Paid-only (show with Crown badge for free users)
{ href: "/live-scores", label: "Live Scores", icon: Activity, paid: true }
{ href: "/performance", label: "My Performance", icon: BarChart3, paid: true }
{ href: "/notifications", label: "Alerts", icon: Bell, paid: true }

// Public
{ href: "/track-record", label: "Track Record", icon: Trophy, paid: false }
```

---

## Step 6 — Nightly Worker Integration

The performance snapshot computation is triggered by `POST /api/performance/compute`.
Call this from your existing nightly analysis worker (`winning-lineup-agent.ts`) after
`analyzeCompletedSlate` succeeds, for every user who has lineups on that slate:

```ts
// In runNightlyAnalysis(), after analyzeCompletedSlate:
const usersWithLineups = await db
  .selectDistinct({ userId: lineups.userId })
  .from(lineups)
  .where(and(eq(lineups.sport, sport), eq(lineups.slateId, slateId)));

for (const { userId } of usersWithLineups) {
  await fetch(`${process.env.APP_URL}/api/performance/compute`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, sport, slateDate, slateId }),
  });
}
```

Similarly, call `POST /api/alerts/deliver` for any injury alerts created that day:
```ts
// After creating an alert, trigger delivery:
await fetch(`${process.env.APP_URL}/api/alerts/deliver`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ userId: alert.userId, alertId: alert.id }),
});
```

---

## Feature Access Summary

| Feature | Free | Paid (any tier) |
|---------|------|-----------------|
| Track Record | ✅ Full | ✅ Full |
| Optimizer (1 lineup) | ✅ Visible | ✅ Full (up to tier limit) |
| Optimizer (2+ lineups) | 🔒 Blurred | ✅ |
| Ownership (top 5 per pos) | ✅ Partial | ✅ Full |
| Live Score Tracker | 🔒 Upsell | ✅ |
| Performance Dashboard | 🔒 Upsell | ✅ |
| Injury Alert Notifications | 🔒 Upsell | ✅ |
| Notification Preferences | 🔒 Upsell | ✅ |
