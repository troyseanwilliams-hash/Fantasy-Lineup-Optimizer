import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Crown, Lock, TrendingUp, TrendingDown, Target, Trophy,
  BarChart3, Calendar, Zap, Loader2, Star, Award,
  ArrowUp, ArrowDown, Minus, Activity
} from "lucide-react";
import { ACTIVE_SPORTS } from "@shared/platform-config";

interface PerformanceSnapshot {
  id: number;
  sport: string;
  slateDate: string;
  lineupCount: number;
  avgUserScore: string | null;
  bestUserScore: string | null;
  optimalScore: string | null;
  fieldAvgScore: string | null;
  avgProjectionAccuracy: string | null;
  vsOptimalPct: string | null;
  vsFieldPct: string | null;
}

interface PerformanceSummary {
  totalSlates: number;
  avgAccuracy: number | null;
  avgVsOptimal: number | null;
  avgVsField: number | null;
  bestSlate: PerformanceSnapshot | null;
}

interface PerformanceData {
  snapshots: PerformanceSnapshot[];
  summary: PerformanceSummary;
}

const SPORT_COLORS: Record<string, string> = {
  NBA: "text-orange-400",
  NHL: "text-cyan-400",
  MLB: "text-red-400",
  NFL: "text-green-400",
  GOLF: "text-lime-400",
  SOCCER: "text-teal-400",
};

function VsOptimalBadge({ pct }: { pct: number | null }) {
  if (pct === null) return <span className="text-slate-500 text-xs">—</span>;
  const rounded = Math.round(pct);
  if (rounded >= 95) return <span className="text-emerald-400 font-black text-sm">{rounded}%</span>;
  if (rounded >= 85) return <span className="text-amber-400 font-black text-sm">{rounded}%</span>;
  return <span className="text-red-400 font-black text-sm">{rounded}%</span>;
}

function AccuracyBar({ ratio }: { ratio: number | null }) {
  if (ratio === null) return (
    <div className="w-full h-1.5 bg-slate-800 rounded-full" />
  );
  const pct = Math.min(100, Math.round(ratio * 100));
  const color = pct >= 100 ? "bg-emerald-500" : pct >= 85 ? "bg-amber-500" : "bg-red-500";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${Math.min(pct, 100)}%` }} />
      </div>
      <span className="text-[10px] font-black text-slate-400 w-8 text-right">{pct}%</span>
    </div>
  );
}

function TrendArrow({ current, prev }: { current: number | null; prev: number | null }) {
  if (current === null || prev === null) return <Minus className="w-3 h-3 text-slate-600" />;
  const diff = current - prev;
  if (diff > 2) return <ArrowUp className="w-3 h-3 text-emerald-400" />;
  if (diff < -2) return <ArrowDown className="w-3 h-3 text-red-400" />;
  return <Minus className="w-3 h-3 text-slate-500" />;
}

function StatCard({
  label, value, subValue, icon, color = "text-white", highlight = false,
}: {
  label: string;
  value: React.ReactNode;
  subValue?: string;
  icon: React.ReactNode;
  color?: string;
  highlight?: boolean;
}) {
  return (
    <Card className={`p-5 ${highlight ? "bg-amber-500/5 border-amber-500/20" : "bg-slate-900/70 border-slate-700/50"}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">{label}</p>
          <p className={`text-2xl font-black tabular-nums ${color}`}>{value}</p>
          {subValue && <p className="text-[11px] text-slate-500 mt-1">{subValue}</p>}
        </div>
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
          highlight ? "bg-amber-500/10" : "bg-slate-800/80"
        }`}>
          {icon}
        </div>
      </div>
    </Card>
  );
}

export default function PerformanceDashboard() {
  const { user } = useAuth();
  const isAdmin = (user as any)?.isAdmin === true;

  const { data: subscription } = useQuery<{ tier: string }>({
    queryKey: ["/api/subscription"],
    enabled: !!user,
  });
  const tier = subscription?.tier || "free";
  const hasAccess = isAdmin || ["pro", "premium", "star"].includes(tier);

  const [selectedSport, setSelectedSport] = useState<string>("ALL");

  const { data, isLoading } = useQuery<PerformanceData>({
    queryKey: ["/api/performance", selectedSport],
    queryFn: async () => {
      const url = selectedSport === "ALL"
        ? "/api/performance"
        : `/api/performance?sport=${selectedSport}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to load performance");
      return res.json();
    },
    enabled: !!user && hasAccess,
  });

  // Compute per-sport breakdown from snapshots
  const sportBreakdown = useMemo(() => {
    if (!data?.snapshots) return [];
    const map: Record<string, { sport: string; count: number; avgVsOptimal: number; avgAccuracy: number }> = {};
    for (const s of data.snapshots) {
      if (!map[s.sport]) map[s.sport] = { sport: s.sport, count: 0, avgVsOptimal: 0, avgAccuracy: 0 };
      const entry = map[s.sport];
      entry.count++;
      entry.avgVsOptimal += Number(s.vsOptimalPct || 0);
      entry.avgAccuracy += Number(s.avgProjectionAccuracy || 1) * 100;
    }
    return Object.values(map).map(e => ({
      ...e,
      avgVsOptimal: Math.round(e.avgVsOptimal / e.count),
      avgAccuracy: Math.round(e.avgAccuracy / e.count),
    }));
  }, [data]);

  if (!hasAccess) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center p-6">
        <Card className="bg-slate-900 border-amber-500/30 p-10 max-w-lg text-center">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-5">
            <BarChart3 className="w-8 h-8 text-amber-400" />
          </div>
          <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-[10px] font-black mb-4">CHAMPION FEATURE</Badge>
          <h2 className="text-2xl font-black text-white mb-3">Performance Dashboard</h2>
          <p className="text-sm text-slate-400 mb-2">Track how your lineups perform versus the algorithm's optimal, the field average, and your own projection accuracy over time.</p>
          <p className="text-xs text-slate-500 mb-6">See exactly where your edge is — and where to improve.</p>
          <Link href="/pricing">
            <Button className="bg-amber-500 hover:bg-amber-600 text-black font-black w-full h-11">
              <Crown className="w-4 h-4 mr-2" /> Upgrade to Champion
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  const summary = data?.summary;
  const snapshots = data?.snapshots || [];

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/60 px-6 py-5">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h1 className="text-xl font-black text-white">Performance Dashboard</h1>
              <p className="text-xs text-slate-400">Your lineup performance vs the optimal and the field</p>
            </div>
          </div>

          {/* Sport filter */}
          <div className="flex gap-1 bg-slate-800/60 rounded-lg p-1 border border-slate-700/50">
            {["ALL", ...ACTIVE_SPORTS].map(s => (
              <button
                key={s}
                onClick={() => setSelectedSport(s)}
                className={`px-3 py-1.5 rounded-md text-[11px] font-black transition-all ${
                  selectedSport === s
                    ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-6 space-y-6">
        {isLoading ? (
          <div className="flex justify-center py-24">
            <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
          </div>
        ) : snapshots.length === 0 ? (
          <Card className="bg-slate-900 border-slate-700 p-12 text-center">
            <Activity className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-white mb-2">No Performance Data Yet</h3>
            <p className="text-sm text-slate-400 mb-6">Build and save lineups to start tracking your performance. Stats appear after game results are finalized.</p>
            <Link href="/optimizer">
              <Button className="bg-amber-500 hover:bg-amber-600 text-black font-bold">
                <Zap className="w-4 h-4 mr-2" /> Build Your First Lineup
              </Button>
            </Link>
          </Card>
        ) : (
          <>
            {/* Summary stats */}
            <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
              <StatCard
                label="Slates Played"
                value={summary?.totalSlates ?? "—"}
                icon={<Calendar className="w-4 h-4 text-slate-400" />}
                subValue="total slates with lineups"
              />
              <StatCard
                label="vs Optimal"
                value={summary?.avgVsOptimal ? `${summary.avgVsOptimal}%` : "—"}
                subValue="avg best lineup / optimal"
                icon={<Trophy className="w-4 h-4 text-amber-400" />}
                color={
                  summary?.avgVsOptimal
                    ? summary.avgVsOptimal >= 90 ? "text-emerald-400"
                    : summary.avgVsOptimal >= 80 ? "text-amber-400"
                    : "text-red-400"
                    : "text-slate-400"
                }
                highlight={!!summary?.avgVsOptimal}
              />
              <StatCard
                label="vs Field"
                value={summary?.avgVsField ? `${summary.avgVsField}%` : "—"}
                subValue="avg lineup / field average"
                icon={<Target className="w-4 h-4 text-blue-400" />}
                color={
                  summary?.avgVsField
                    ? summary.avgVsField >= 105 ? "text-emerald-400"
                    : summary.avgVsField >= 95 ? "text-amber-400"
                    : "text-red-400"
                    : "text-slate-400"
                }
              />
              <StatCard
                label="Proj. Accuracy"
                value={summary?.avgAccuracy ? `${summary.avgAccuracy}%` : "—"}
                subValue="actual / projected pts ratio"
                icon={<Zap className="w-4 h-4 text-purple-400" />}
                color={
                  summary?.avgAccuracy
                    ? summary.avgAccuracy >= 95 ? "text-emerald-400"
                    : summary.avgAccuracy >= 85 ? "text-amber-400"
                    : "text-red-400"
                    : "text-slate-400"
                }
              />
            </div>

            {/* Best slate highlight */}
            {summary?.bestSlate && (
              <Card className="bg-amber-500/5 border-amber-500/20 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span className="text-xs font-black text-amber-400 uppercase tracking-widest">Best Slate</span>
                </div>
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <p className="text-lg font-black text-white">
                      {new Date(summary.bestSlate.slateDate).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
                    </p>
                    <p className="text-sm text-slate-400">{summary.bestSlate.sport} · {summary.bestSlate.lineupCount} lineup{summary.bestSlate.lineupCount > 1 ? "s" : ""}</p>
                  </div>
                  <div className="flex gap-6">
                    <div className="text-center">
                      <p className="text-2xl font-black text-emerald-400">{Number(summary.bestSlate.bestUserScore || 0).toFixed(1)}</p>
                      <p className="text-[10px] text-slate-500 font-bold uppercase">Best Score</p>
                    </div>
                    {summary.bestSlate.optimalScore && (
                      <div className="text-center">
                        <p className="text-2xl font-black text-amber-400">{Number(summary.bestSlate.optimalScore).toFixed(1)}</p>
                        <p className="text-[10px] text-slate-500 font-bold uppercase">Optimal</p>
                      </div>
                    )}
                    <div className="text-center">
                      <p className="text-2xl font-black text-white">{Math.round(Number(summary.bestSlate.vsOptimalPct || 0))}%</p>
                      <p className="text-[10px] text-slate-500 font-bold uppercase">vs Optimal</p>
                    </div>
                  </div>
                </div>
              </Card>
            )}

            {/* Per-sport breakdown */}
            {sportBreakdown.length > 1 && (
              <div>
                <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3">By Sport</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
                  {sportBreakdown.map(s => (
                    <Card
                      key={s.sport}
                      className="bg-slate-900/60 border-slate-700/40 p-4 cursor-pointer hover:border-slate-600/60 transition-colors"
                      onClick={() => setSelectedSport(s.sport)}
                    >
                      <p className={`text-sm font-black ${SPORT_COLORS[s.sport] || "text-white"} mb-1`}>{s.sport}</p>
                      <p className="text-lg font-black text-white">{s.avgVsOptimal}%</p>
                      <p className="text-[10px] text-slate-500">vs optimal</p>
                      <p className="text-[10px] text-slate-600 mt-1">{s.count} slate{s.count > 1 ? "s" : ""}</p>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Slate-by-slate history */}
            <div>
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3">Slate History</h2>
              <Card className="bg-slate-900/60 border-slate-700/40 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left min-w-[640px]">
                    <thead className="border-b border-slate-800">
                      <tr className="text-[11px] font-black text-slate-400 uppercase tracking-wider">
                        <th className="px-5 py-3">Date</th>
                        <th className="px-5 py-3">Sport</th>
                        <th className="px-5 py-3 text-right">Lineups</th>
                        <th className="px-5 py-3 text-right">Best Score</th>
                        <th className="px-5 py-3 text-right">Optimal</th>
                        <th className="px-5 py-3 text-right">vs Optimal</th>
                        <th className="px-5 py-3">Proj. Accuracy</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                      {snapshots.map((s, idx) => {
                        const prev = snapshots[idx + 1];
                        const vsOptimal = s.vsOptimalPct ? Number(s.vsOptimalPct) : null;
                        return (
                          <tr key={s.id} className="hover:bg-slate-800/20 transition-colors">
                            <td className="px-5 py-3 text-sm font-bold text-white">
                              {new Date(s.slateDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                            </td>
                            <td className="px-5 py-3">
                              <span className={`text-xs font-black ${SPORT_COLORS[s.sport] || "text-white"}`}>{s.sport}</span>
                            </td>
                            <td className="px-5 py-3 text-right text-xs font-bold text-slate-400">{s.lineupCount}</td>
                            <td className="px-5 py-3 text-right text-sm font-black text-white">
                              {s.bestUserScore ? Number(s.bestUserScore).toFixed(1) : "—"}
                            </td>
                            <td className="px-5 py-3 text-right text-xs font-bold text-slate-400">
                              {s.optimalScore ? Number(s.optimalScore).toFixed(1) : "—"}
                            </td>
                            <td className="px-5 py-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <TrendArrow
                                  current={vsOptimal}
                                  prev={prev?.vsOptimalPct ? Number(prev.vsOptimalPct) : null}
                                />
                                <VsOptimalBadge pct={vsOptimal} />
                              </div>
                            </td>
                            <td className="px-5 py-3 w-36">
                              <AccuracyBar ratio={s.avgProjectionAccuracy ? Number(s.avgProjectionAccuracy) : null} />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
