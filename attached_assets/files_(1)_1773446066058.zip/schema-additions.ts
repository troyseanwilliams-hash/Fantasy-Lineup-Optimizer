// ============================================================
// SCHEMA ADDITIONS — append these to shared/schema.ts
// Covers all 5 new features:
//   1. Live Lineup Score Tracker
//   2. Injury Alert SMS/Email Delivery
//   3. Performance Dashboard
//   4. Track Record (no new tables needed — uses winning_lineups)
//   5. Blur/teaser (no new tables — subscription-gated in routes)
// ============================================================

import { pgTable, text, serial, integer, boolean, timestamp, numeric, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";
import { lineups, players, slates } from "./schema";

// ============================================================
// LINEUP SCORES — Live scoring for saved lineups
// Polled or pushed from DK API post-lock.
// One row per lineup per score update (latest row = current score).
// ============================================================
export const lineupScores = pgTable("lineup_scores", {
  id: serial("id").primaryKey(),
  lineupId: integer("lineup_id").notNull().references(() => lineups.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id),
  sport: text("sport").notNull(),
  slateId: integer("slate_id").notNull().references(() => slates.id),
  // Per-player live scores: array of { playerId, playerName, position, livePoints, projectedPoints, isPlaying, isComplete }
  playerScores: jsonb("player_scores").$type<Array<{
    playerId: number;
    playerName: string;
    position: string;
    livePoints: number;
    projectedPoints: number;
    isPlaying: boolean;
    isComplete: boolean;
    gameStatus: string; // "pregame" | "live" | "final"
  }>>().notNull(),
  totalLivePoints: numeric("total_live_points").notNull().default("0"),
  totalProjectedPoints: numeric("total_projected_points").notNull(),
  // Contest rank if available (populated from DK API if dkEntryId exists on lineup)
  contestRank: integer("contest_rank"),
  contestTotalEntries: integer("contest_total_entries"),
  contestPrize: text("contest_prize"),
  // Scoring state
  scoringStatus: text("scoring_status").notNull().default("pregame"), // "pregame" | "live" | "final"
  lastUpdatedAt: timestamp("last_updated_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_lineup_scores_lineup_id").on(table.lineupId),
  index("idx_lineup_scores_user_id").on(table.userId),
  index("idx_lineup_scores_slate_id").on(table.slateId),
]);

export const insertLineupScoreSchema = createInsertSchema(lineupScores).omit({ id: true, createdAt: true });
export type LineupScore = typeof lineupScores.$inferSelect;
export type InsertLineupScore = z.infer<typeof insertLineupScoreSchema>;

// ============================================================
// ALERT DELIVERY LOG — tracks SMS/email sends to prevent dupes
// One row per alert delivery attempt.
// ============================================================
export const alertDeliveries = pgTable("alert_deliveries", {
  id: serial("id").primaryKey(),
  alertId: integer("alert_id").notNull().references(() => import("./schema").then(m => m.alerts).id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id),
  channel: text("channel").notNull(), // "sms" | "email" | "push"
  status: text("status").notNull().default("pending"), // "pending" | "sent" | "failed" | "bounced"
  externalId: text("external_id"), // Twilio SID or SendGrid message ID
  errorMessage: text("error_message"),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_alert_deliveries_alert_id").on(table.alertId),
  index("idx_alert_deliveries_user_id").on(table.userId),
]);

export const insertAlertDeliverySchema = createInsertSchema(alertDeliveries).omit({ id: true, createdAt: true });
export type AlertDelivery = typeof alertDeliveries.$inferSelect;
export type InsertAlertDelivery = z.infer<typeof insertAlertDeliverySchema>;

// ============================================================
// NOTIFICATION PREFERENCES — per-user channel settings
// Extends what's already on users (smsConsent, emailConsent)
// with granular control over alert types.
// ============================================================
export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id).unique(),
  // Channel enables
  smsEnabled: boolean("sms_enabled").notNull().default(false),
  emailEnabled: boolean("email_enabled").notNull().default(true),
  pushEnabled: boolean("push_enabled").notNull().default(false),
  // Alert type enables
  injuryAlerts: boolean("injury_alerts").notNull().default(true),
  lineupScoringAlerts: boolean("lineup_scoring_alerts").notNull().default(true),
  slateStartAlerts: boolean("slate_start_alerts").notNull().default(false),
  // Timing — how many minutes before lock to send pre-game alerts
  preGameAlertMinutes: integer("pre_game_alert_minutes").notNull().default(30),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).omit({ id: true, updatedAt: true });
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreferences = z.infer<typeof insertNotificationPreferencesSchema>;

// ============================================================
// PERFORMANCE SNAPSHOTS — daily summary of user lineup performance
// Used by the Performance Dashboard.
// One row per user per sport per date.
// ============================================================
export const performanceSnapshots = pgTable("performance_snapshots", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  sport: text("sport").notNull(),
  slateDate: text("slate_date").notNull(), // "YYYY-MM-DD"
  slateId: integer("slate_id").references(() => slates.id),
  // User lineup aggregate stats
  lineupCount: integer("lineup_count").notNull().default(0),
  avgUserScore: numeric("avg_user_score"),
  bestUserScore: numeric("best_user_score"),
  // Comparison benchmarks
  optimalScore: numeric("optimal_score"), // from winning_lineups
  fieldAvgScore: numeric("field_avg_score"), // average DFS score that day
  // Projection accuracy
  avgProjectionAccuracy: numeric("avg_projection_accuracy"), // actual/projected ratio
  // Derived metrics
  vsOptimalPct: numeric("vs_optimal_pct"), // bestUserScore / optimalScore * 100
  vsFieldPct: numeric("vs_field_pct"), // avgUserScore / fieldAvgScore * 100
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_perf_snapshots_user_sport").on(table.userId, table.sport),
  index("idx_perf_snapshots_date").on(table.slateDate),
]);

export const insertPerformanceSnapshotSchema = createInsertSchema(performanceSnapshots).omit({ id: true, createdAt: true });
export type PerformanceSnapshot = typeof performanceSnapshots.$inferSelect;
export type InsertPerformanceSnapshot = z.infer<typeof insertPerformanceSnapshotSchema>;

// ============================================================
// MIGRATION NOTE
// Run this SQL after deploying schema changes:
//
// CREATE INDEX IF NOT EXISTS idx_lineup_scores_lineup_id ON lineup_scores(lineup_id);
// CREATE INDEX IF NOT EXISTS idx_lineup_scores_user_id ON lineup_scores(user_id);
// CREATE INDEX IF NOT EXISTS idx_lineup_scores_slate_id ON lineup_scores(slate_id);
// CREATE INDEX IF NOT EXISTS idx_alert_deliveries_alert_id ON alert_deliveries(alert_id);
// CREATE INDEX IF NOT EXISTS idx_alert_deliveries_user_id ON alert_deliveries(user_id);
// CREATE INDEX IF NOT EXISTS idx_perf_snapshots_user_sport ON performance_snapshots(user_id, sport);
// CREATE INDEX IF NOT EXISTS idx_perf_snapshots_date ON performance_snapshots(slate_date);
//
// Trigger for notification_preferences.updated_at:
// CREATE TRIGGER notif_prefs_updated_at BEFORE UPDATE ON notification_preferences
//   FOR EACH ROW EXECUTE FUNCTION set_updated_at();
// ============================================================
