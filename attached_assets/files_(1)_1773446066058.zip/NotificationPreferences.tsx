import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Link } from "wouter";
import {
  Bell, BellOff, MessageSquare, Mail, Smartphone,
  ShieldAlert, Activity, Clock, Save, Crown, Lock,
  CheckCircle2, AlertTriangle, Loader2, Info
} from "lucide-react";

interface NotifPrefs {
  smsEnabled: boolean;
  emailEnabled: boolean;
  pushEnabled: boolean;
  injuryAlerts: boolean;
  lineupScoringAlerts: boolean;
  slateStartAlerts: boolean;
  preGameAlertMinutes: number;
}

interface AlertWithDelivery {
  id: number;
  playerName: string;
  sport: string;
  type: string;
  title: string;
  message: string;
  severity: string;
  isRead: boolean;
  createdAt: string;
  deliveries: Array<{
    channel: string;
    status: string;
    sentAt: string | null;
  }>;
}

const SEVERITY_STYLES: Record<string, { badge: string; icon: JSX.Element }> = {
  critical: {
    badge: "bg-red-500/20 text-red-400 border-red-500/30",
    icon: <ShieldAlert className="w-3.5 h-3.5 text-red-400" />,
  },
  warning: {
    badge: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    icon: <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />,
  },
  info: {
    badge: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    icon: <Info className="w-3.5 h-3.5 text-blue-400" />,
  },
};

function DeliveryChip({ channel, status }: { channel: string; status: string }) {
  const colors = status === "sent"
    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
    : status === "failed"
    ? "bg-red-500/10 text-red-400 border-red-500/20"
    : "bg-slate-700/50 text-slate-400 border-slate-600/30";
  const icon = channel === "sms"
    ? <MessageSquare className="w-3 h-3" />
    : channel === "email"
    ? <Mail className="w-3 h-3" />
    : <Smartphone className="w-3 h-3" />;

  return (
    <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded border ${colors}`}>
      {icon} {channel.toUpperCase()}
    </span>
  );
}

function PrefRow({
  icon, label, description, checked, onChange, disabled = false,
}: {
  icon: React.ReactNode;
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <div className={`flex items-start gap-4 py-4 ${disabled ? "opacity-40 pointer-events-none" : ""}`}>
      <div className="w-8 h-8 rounded-lg bg-slate-800/80 flex items-center justify-center shrink-0 mt-0.5">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold text-white">{label}</p>
        <p className="text-xs text-slate-400 mt-0.5">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} className="shrink-0 mt-1" />
    </div>
  );
}

export default function NotificationPreferences() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isAdmin = (user as any)?.isAdmin === true;
  const userPhone = (user as any)?.phone;
  const userEmail = (user as any)?.email;

  const { data: subscription } = useQuery<{ tier: string }>({
    queryKey: ["/api/subscription"],
    enabled: !!user,
  });
  const tier = subscription?.tier || "free";
  const hasAccess = isAdmin || ["pro", "premium", "star"].includes(tier);

  const { data: prefs, isLoading: prefsLoading } = useQuery<NotifPrefs>({
    queryKey: ["/api/notification-preferences"],
    enabled: !!user && hasAccess,
  });

  const { data: recentAlerts, isLoading: alertsLoading } = useQuery<AlertWithDelivery[]>({
    queryKey: ["/api/alerts/with-delivery"],
    enabled: !!user && hasAccess,
    refetchInterval: 60000,
  });

  const [form, setForm] = useState<NotifPrefs>({
    smsEnabled: false,
    emailEnabled: true,
    pushEnabled: false,
    injuryAlerts: true,
    lineupScoringAlerts: true,
    slateStartAlerts: false,
    preGameAlertMinutes: 30,
  });

  useEffect(() => {
    if (prefs) setForm(prefs);
  }, [prefs]);

  const saveMutation = useMutation({
    mutationFn: async (data: NotifPrefs) => {
      const res = await apiRequest("PUT", "/api/notification-preferences", data);
      if (!res.ok) throw new Error("Failed to save");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notification-preferences"] });
      toast({ title: "Preferences Saved", description: "Your notification settings have been updated." });
    },
    onError: () => {
      toast({ title: "Save Failed", description: "Could not save preferences. Please try again.", variant: "destructive" });
    },
  });

  const set = (key: keyof NotifPrefs) => (val: boolean | number) =>
    setForm(f => ({ ...f, [key]: val }));

  if (!hasAccess) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center p-6">
        <Card className="bg-slate-900 border-amber-500/30 p-8 max-w-md text-center">
          <div className="w-16 h-16 rounded-full bg-amber-500/10 flex items-center justify-center mx-auto mb-5">
            <Bell className="w-8 h-8 text-amber-400" />
          </div>
          <h2 className="text-xl font-black text-white mb-2">Injury Alert Notifications</h2>
          <p className="text-sm text-slate-400 mb-6">
            Get SMS and email alerts for injuries to players in your lineups — up to 30 minutes before lock.
          </p>
          <Link href="/pricing">
            <Button className="bg-amber-500 hover:bg-amber-600 text-black font-black w-full">
              <Crown className="w-4 h-4 mr-2" /> Upgrade to Enable Alerts
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="max-w-3xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
            <Bell className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white">Notifications</h1>
            <p className="text-sm text-slate-400">Injury alerts, live scoring updates, and pre-game reminders</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: settings */}
          <div className="lg:col-span-2 space-y-5">

            {/* Channel settings */}
            <Card className="bg-slate-900/80 border-slate-700/50 p-5">
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Delivery Channels</h2>
              <p className="text-[11px] text-slate-500 mb-4">Choose how you want to receive alerts</p>

              <div className="divide-y divide-slate-800/50">
                <PrefRow
                  icon={<Mail className="w-4 h-4 text-blue-400" />}
                  label="Email Alerts"
                  description={userEmail ? `Send to ${userEmail}` : "No email on file — update your profile"}
                  checked={form.emailEnabled}
                  onChange={set("emailEnabled")}
                  disabled={!userEmail}
                />
                <PrefRow
                  icon={<MessageSquare className="w-4 h-4 text-emerald-400" />}
                  label="SMS / Text Alerts"
                  description={
                    userPhone
                      ? `Send to ${userPhone}`
                      : "Add a phone number to your profile to enable SMS"
                  }
                  checked={form.smsEnabled}
                  onChange={set("smsEnabled")}
                  disabled={!userPhone}
                />
              </div>

              {!userPhone && (
                <div className="mt-3 p-3 rounded-lg bg-slate-800/60 border border-slate-700/50 flex items-start gap-2">
                  <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                  <p className="text-xs text-slate-400">
                    Add a phone number in your{" "}
                    <Link href="/settings" className="text-emerald-400 font-bold underline">account settings</Link>
                    {" "}to enable SMS alerts.
                  </p>
                </div>
              )}
            </Card>

            {/* Alert type settings */}
            <Card className="bg-slate-900/80 border-slate-700/50 p-5">
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Alert Types</h2>
              <p className="text-[11px] text-slate-500 mb-4">Control which events trigger notifications</p>

              <div className="divide-y divide-slate-800/50">
                <PrefRow
                  icon={<ShieldAlert className="w-4 h-4 text-red-400" />}
                  label="Injury Alerts"
                  description="Notified when a player in your saved lineups is injured or listed as questionable"
                  checked={form.injuryAlerts}
                  onChange={set("injuryAlerts")}
                />
                <PrefRow
                  icon={<Activity className="w-4 h-4 text-emerald-400" />}
                  label="Live Scoring Milestones"
                  description="Get notified when your lineup hits key scoring milestones during games"
                  checked={form.lineupScoringAlerts}
                  onChange={set("lineupScoringAlerts")}
                />
                <PrefRow
                  icon={<Clock className="w-4 h-4 text-amber-400" />}
                  label="Pre-Game Reminders"
                  description="Reminder before slate locks with any last-minute injury news"
                  checked={form.slateStartAlerts}
                  onChange={set("slateStartAlerts")}
                />
              </div>

              {/* Pre-game timing */}
              {form.slateStartAlerts && (
                <div className="mt-4 pt-4 border-t border-slate-800/50">
                  <label className="text-xs font-bold text-slate-400 block mb-2">
                    Send reminder <span className="text-white">{form.preGameAlertMinutes} minutes</span> before lock
                  </label>
                  <input
                    type="range"
                    min={15}
                    max={120}
                    step={15}
                    value={form.preGameAlertMinutes}
                    onChange={e => set("preGameAlertMinutes")(Number(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                  <div className="flex justify-between text-[10px] text-slate-600 mt-1">
                    <span>15 min</span><span>30</span><span>60</span><span>90</span><span>2 hr</span>
                  </div>
                </div>
              )}
            </Card>

            <Button
              onClick={() => saveMutation.mutate(form)}
              disabled={saveMutation.isPending}
              className="w-full bg-amber-500 hover:bg-amber-600 text-black font-black h-11"
            >
              {saveMutation.isPending
                ? <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                : <Save className="w-4 h-4 mr-2" />}
              Save Preferences
            </Button>
          </div>

          {/* Right: recent alerts */}
          <div className="lg:col-span-1">
            <Card className="bg-slate-900/80 border-slate-700/50 p-4">
              <h2 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3">Recent Alerts</h2>

              {alertsLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-5 h-5 text-slate-500 animate-spin" />
                </div>
              ) : !recentAlerts || recentAlerts.length === 0 ? (
                <div className="text-center py-8">
                  <BellOff className="w-8 h-8 text-slate-700 mx-auto mb-2" />
                  <p className="text-xs text-slate-500">No alerts yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentAlerts.slice(0, 10).map(alert => {
                    const style = SEVERITY_STYLES[alert.severity] || SEVERITY_STYLES.info;
                    return (
                      <div
                        key={alert.id}
                        className={`p-3 rounded-lg border ${
                          alert.isRead ? "bg-slate-800/30 border-slate-700/30" : "bg-slate-800/60 border-slate-600/50"
                        }`}
                      >
                        <div className="flex items-start gap-2 mb-1.5">
                          {style.icon}
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold text-white leading-tight">{alert.title}</p>
                            <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">{alert.message}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 flex-wrap mt-2">
                          {alert.deliveries.map((d, i) => (
                            <DeliveryChip key={i} channel={d.channel} status={d.status} />
                          ))}
                          <span className="text-[10px] text-slate-600 ml-auto">
                            {new Date(alert.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
