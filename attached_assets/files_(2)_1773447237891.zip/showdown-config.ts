// ============================================================
// SHOWDOWN CONFIG — append to shared/platform-config.ts
// Showdown (single-game) format for NBA and NFL on DraftKings
// and FanDuel. Captain/MVP slot scores at a multiplier.
// ============================================================

export interface ShowdownSlot {
  key: string;           // "CPT" | "FLEX1" etc.
  label: string;         // display label
  multiplier: number;    // points multiplier (1.5 for CPT, 2.0 for MVP)
  salaryMultiplier: number; // salary multiplier (same as points for DK CPT)
  isCaptain: boolean;    // whether this is the premium slot
  eligiblePositions: string[] | "ALL"; // "ALL" = any position eligible
}

export interface ShowdownConfig {
  platform: Platform;
  sport: "NBA" | "NFL";
  label: string;
  shortLabel: string;
  salaryCap: number;
  slots: ShowdownSlot[];
  // Minimum players required from the featured game
  minPlayersFromGame: number;
  // Max players from same team (showdown-specific stack rule)
  maxFromOneTeam: number | null;
}

export const SHOWDOWN_CONFIGS: Record<string, Record<Platform, ShowdownConfig>> = {
  NBA: {
    draftkings: {
      platform: "draftkings",
      sport: "NBA",
      label: "DraftKings Showdown",
      shortLabel: "DK SD",
      salaryCap: 50000,
      // CPT salary = 1.5x the listed salary; CPT scores 1.5x points
      slots: [
        { key: "CPT",   label: "CPT",  multiplier: 1.5, salaryMultiplier: 1.5, isCaptain: true,  eligiblePositions: "ALL" },
        { key: "FLEX1", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "FLEX2", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "FLEX3", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "FLEX4", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "FLEX5", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
      ],
      minPlayersFromGame: 6,
      maxFromOneTeam: null, // no team stack limit in DK NBA showdown
    },
    fanduel: {
      platform: "fanduel",
      sport: "NBA",
      label: "FanDuel MVP",
      shortLabel: "FD MVP",
      salaryCap: 60000,
      // FanDuel uses MVP (2x) + 4 UTIL (standard)
      slots: [
        { key: "MVP",   label: "MVP",  multiplier: 2.0, salaryMultiplier: 1.0, isCaptain: true,  eligiblePositions: "ALL" },
        { key: "UTIL1", label: "UTIL", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "UTIL2", label: "UTIL", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "UTIL3", label: "UTIL", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "UTIL4", label: "UTIL", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
      ],
      minPlayersFromGame: 5,
      maxFromOneTeam: null,
    },
  },
  NFL: {
    draftkings: {
      platform: "draftkings",
      sport: "NFL",
      label: "DraftKings Showdown",
      shortLabel: "DK SD",
      salaryCap: 50000,
      slots: [
        { key: "CPT",   label: "CPT",  multiplier: 1.5, salaryMultiplier: 1.5, isCaptain: true,  eligiblePositions: "ALL" },
        { key: "FLEX1", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "FLEX2", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "FLEX3", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "FLEX4", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "FLEX5", label: "FLEX", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
      ],
      minPlayersFromGame: 6,
      maxFromOneTeam: null,
    },
    fanduel: {
      platform: "fanduel",
      sport: "NFL",
      label: "FanDuel MVP",
      shortLabel: "FD MVP",
      salaryCap: 60000,
      slots: [
        { key: "MVP",   label: "MVP",  multiplier: 2.0, salaryMultiplier: 1.0, isCaptain: true,  eligiblePositions: "ALL" },
        { key: "UTIL1", label: "UTIL", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "UTIL2", label: "UTIL", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "UTIL3", label: "UTIL", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
        { key: "UTIL4", label: "UTIL", multiplier: 1.0, salaryMultiplier: 1.0, isCaptain: false, eligiblePositions: "ALL" },
      ],
      minPlayersFromGame: 5,
      maxFromOneTeam: null,
    },
  },
};

export function getShowdownConfig(sport: "NBA" | "NFL", platform: Platform): ShowdownConfig {
  const sportConfigs = SHOWDOWN_CONFIGS[sport];
  if (!sportConfigs) throw new Error(`No showdown config for sport: ${sport}`);
  const config = sportConfigs[platform];
  if (!config) throw new Error(`No showdown config for platform: ${platform}`);
  return config;
}

// Compute effective salary of a player in a given slot
// (CPT costs 1.5x the base salary on DraftKings)
export function getEffectiveSalary(baseSalary: number, slot: ShowdownSlot): number {
  return Math.round(baseSalary * slot.salaryMultiplier);
}

// Compute projected points for a player in a given slot
export function getProjectedPoints(baseProjection: number, slot: ShowdownSlot): number {
  return Math.round(baseProjection * slot.multiplier * 100) / 100;
}
