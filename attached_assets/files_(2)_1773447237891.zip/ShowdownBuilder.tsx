import { useState, useMemo, useCallback, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient as qc } from "@/lib/queryClient";
import type { Slate } from "@shared/schema";
import {
  Zap, Save, Search, Lock, Unlock, X, Crown, Loader2,
  ChevronDown, ChevronUp, ArrowUpDown, Star, Shield,
  TrendingUp, AlertTriangle, Download, RefreshCw,
  Swords, Trophy, Target, DollarSign, Users, Activity
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// ── Types ─────────────────────────────────────────────────────────────────────

type Sport = "NBA" | "NFL";
type Platform = "draftkings" | "fanduel";

interface ShowdownPlayer {
  id: number;
  name: string;
  team: string;
  position: string;
  salary: number;
  projectedPoints: string;
  fppg: string;
  injuryStatus: string | null;
  gameInfo: string | null;
  boostScore: string | null;
  draftKingsPlayerId: number | null;
}

interface ShowdownSlot {
  key: string;
  label: string;
  multiplier: number;
  salaryMultiplier: number;
  isCaptain: boolean;
}

interface LineupPlayer {
  id: number;
  name: string;
  team: string;
  position: string;
  baseSalary: number;
  effectiveSalary: number;
  baseProjection: number;
  effectiveProjection: number;
  slot: string;
  isCaptain: boolean;
  injuryStatus: string | null;
  draftKingsPlayerId: number | null;
}

interface GeneratedLineup {
  players: LineupPlayer[];
  totalSalary: number;
  totalProjectedPoints: number;
  captainName: string;
  captainTeam: string;
}

interface ShowdownResponse {
  lineups: GeneratedLineup[];
  config: {
    salaryCap: number;
    slots: ShowdownSlot[];
    platform: string;
    sport: string;
  };
}

interface GameInfo {
  key: string;
  away: string;
  home: string;
  time: string;
  playerCount: number;
}

// ── Constants ─────────────────────────────────────────────────────────────────

const SPORT_CONFIG: Record<Sport, { color: string; bg: string; border: string; accentText: string }> = {
  NBA: { color: "from-orange-600/20 to-slate-950", bg: "bg-orange-500/10", border: "border-orange-500/25", accentText: "text-orange-400" },
  NFL: { color: "from-green-700/20 to-slate-950", bg: "bg-green-500/10", border: "border-green-500/25", accentText: "text-green-400" },
};

const POSITION_COLORS: Record<string, string> = {
  PG: "text-sky-400", SG: "text-blue-400", SF: "text-indigo-400",
  PF: "text-violet-400", C: "text-purple-400",
  QB: "text-amber-400", RB: "text-emerald-400", WR: "text-cyan-400",
  TE: "text-teal-400", DST: "text-rose-400",
};

const INJURY_COLORS: Record<string, string> = {
  OUT: "text-red-400", Doubtful: "text-orange-400",
  Questionable: "text-amber-400", Probable: "text-lime-400",
};

// ── Helper functions ──────────────────────────────────────────────────────────

function getCaptainLabel(platform: Platform): string {
  return platform === "fanduel" ? "MVP" : "CPT";
}

function getCaptainMultiplier(platform: Platform): number {
  return platform === "fanduel" ? 2.0 : 1.5;
}

function getCaptainSalaryMultiplier(platform: Platform): number {
  return platform === "fanduel" ? 1.0 : 1.5;
}

function getEffectiveSalary(baseSalary: number, isCaptain: boolean, platform: Platform): number {
  if (!isCaptain) return baseSalary;
  return Math.round(baseSalary * getCaptainSalaryMultiplier(platform));
}

function getEffectiveProj(baseProj: number, isCaptain: boolean, platform: Platform): number {
  if (!isCaptain) return baseProj;
  return Math.round(baseProj * getCaptainMultiplier(platform) * 100) / 100;
}

function posColor(pos: string): string {
  const primary = pos.split("/")[0];
  return POSITION_COLORS[primary] || "text-slate-400";
}

// ── Sub-components ────────────────────────────────────────────────────────────

function CaptainGlow({ sport }: { sport: Sport }) {
  return (
    <div className="absolute inset-0 pointer-events-none">
      <div className={`absolute inset-0 rounded-xl ${
        sport === "NBA" ? "bg-amber-500/8" : "bg-amber-500/8"
      }`} />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-amber-500/20 to-transparent" />
    </div>
  );
}

function SlotBadge({ isCaptain, platform }: { isCaptain: boolean; platform: Platform }) {
  if (isCaptain) return (
    <div className="flex items-center gap-1 bg-amber-500/20 border border-amber-500/40 rounded-lg px-2.5 py-1.5 shrink-0">
      <Crown className="w-3 h-3 text-amber-400" />
      <span className="text-[11px] font-black text-amber-400 tracking-wider">
        {getCaptainLabel(platform)}
      </span>
      <span className="text-[9px] font-black text-amber-300/70 ml-0.5">
        {getCaptainMultiplier(platform)}×
      </span>
    </div>
  );
  return (
    <div className="flex items-center bg-slate-800/60 border border-slate-700/40 rounded-lg px-2.5 py-1.5 shrink-0">
      <span className="text-[11px] font-black text-slate-400">FLEX</span>
    </div>
  );
}

function TeamChip({ team, sport }: { team: string; sport: Sport }) {
  return (
    <span className={`text-[10px] font-black px-1.5 py-0.5 rounded ${
      sport === "NBA" ? "bg-orange-500/10 text-orange-300/80" : "bg-green-500/10 text-green-300/80"
    }`}>
      {team}
    </span>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

export default function ShowdownBuilder() {
  const { user } = useAuth();
  const { toast } = useToast();
  const userId = (user as any)?.id as string | undefined;

  // ── Sport / platform state
  const [sport, setSport] = useState<Sport>("NBA");
  const [platform, setPlatform] = useState<Platform>("draftkings");
  const [selectedSlateId, setSelectedSlateId] = useState<number | null>(null);
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  // ── Player pool state
  const [search, setSearch] = useState("");
  const [posFilter, setPosFilter] = useState("ALL");
  const [teamFilter, setTeamFilter] = useState("ALL");
  const [sortKey, setSortKey] = useState<"proj" | "salary" | "value" | "name">("proj");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [lockedCaptainId, setLockedCaptainId] = useState<number | null>(null);
  const [lockedFlexIds, setLockedFlexIds] = useState<number[]>([]);
  const [excludedIds, setExcludedIds] = useState<number[]>([]);

  // ── Generated lineup state
  const [lineupCount, setLineupCount] = useState(1);
  const [generatedLineups, setGeneratedLineups] = useState<GeneratedLineup[]>([]);
  const [activeLineupIdx, setActiveLineupIdx] = useState(0);
  const [savedIndices, setSavedIndices] = useState<Set<number>>(new Set());
  const [mobileView, setMobileView] = useState<"pool" | "lineup">("pool");

  const captainLabel = getCaptainLabel(platform);
  const sColors = SPORT_CONFIG[sport];

  // ── Data fetching
  const { data: slates } = useQuery<Slate[]>({ queryKey: ["/api/slates"] });

  const sportSlates = useMemo(() =>
    slates?.filter(s => s.sport === sport) || [],
    [slates, sport]
  );

  const activeSlateId = selectedSlateId || sportSlates[0]?.id || null;

  const { data: playerData, isLoading: playersLoading } = useQuery<{
    players: ShowdownPlayer[];
    games: GameInfo[];
  }>({
    queryKey: ["/api/showdown/players", activeSlateId],
    queryFn: async () => {
      const res = await fetch(`/api/showdown/players/${activeSlateId}`);
      if (!res.ok) throw new Error("Failed to load players");
      return res.json();
    },
    enabled: !!activeSlateId,
  });

  const allPlayers = playerData?.players || [];
  const games = playerData?.games || [];

  // Auto-select first game
  useEffect(() => {
    if (games.length > 0 && !selectedGame) {
      setSelectedGame(games[0].key);
    }
  }, [games]);

  // Reset on sport/platform change
  useEffect(() => {
    setGeneratedLineups([]);
    setLockedCaptainId(null);
    setLockedFlexIds([]);
    setExcludedIds([]);
    setSavedIndices(new Set());
    setSelectedGame(null);
    setActiveLineupIdx(0);
  }, [sport, platform, activeSlateId]);

  // ── Filter & sort players
  const gamePlayers = useMemo(() => {
    if (!selectedGame) return allPlayers;
    // Filter to players from the selected game
    const game = games.find(g => g.key === selectedGame);
    if (!game) return allPlayers;
    return allPlayers.filter(p =>
      p.team === game.away || p.team === game.home ||
      p.opponent === game.away || p.opponent === game.home
    );
  }, [allPlayers, selectedGame, games]);

  const positions = useMemo(() => {
    const pos = new Set<string>();
    gamePlayers.forEach(p => p.position.split("/").forEach(x => pos.add(x)));
    return ["ALL", ...Array.from(pos).sort()];
  }, [gamePlayers]);

  const teams = useMemo(() => {
    const t = new Set(gamePlayers.map(p => p.team));
    return ["ALL", ...Array.from(t).sort()];
  }, [gamePlayers]);

  const filteredPlayers = useMemo(() => {
    return gamePlayers
      .filter(p => {
        if (excludedIds.includes(p.id)) return false;
        if (search && !p.name.toLowerCase().includes(search.toLowerCase()) &&
            !p.team.toLowerCase().includes(search.toLowerCase())) return false;
        if (posFilter !== "ALL" && !p.position.includes(posFilter)) return false;
        if (teamFilter !== "ALL" && p.team !== teamFilter) return false;
        return true;
      })
      .map(p => ({
        ...p,
        value: Number(p.projectedPoints) / Math.max(p.salary / 1000, 0.1),
        captainSalary: getEffectiveSalary(p.salary, true, platform),
        captainProj: getEffectiveProj(Number(p.projectedPoints), true, platform),
      }))
      .sort((a, b) => {
        let av: number, bv: number;
        if (sortKey === "proj")   { av = a.value; bv = b.value; }
        else if (sortKey === "salary") { av = a.salary; bv = b.salary; }
        else if (sortKey === "value")  { av = a.value; bv = b.value; }
        else { return sortDir === "asc" ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name); }
        return sortDir === "asc" ? av - bv : bv - av;
      });
  }, [gamePlayers, search, posFilter, teamFilter, excludedIds, sortKey, sortDir, platform]);

  // ── Current active lineup
  const activeLineup = generatedLineups[activeLineupIdx] || null;

  // ── Salary remaining in active lineup
  const activeSalaryUsed = activeLineup?.totalSalary || 0;

  // ── Optimize mutation
  const optimizeMutation = useMutation<ShowdownResponse, Error, any>({
    mutationFn: async (body) => {
      const res = await apiRequest("POST", "/api/showdown/optimize", body);
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Optimization failed");
      }
      return res.json();
    },
    onSuccess: (data) => {
      setGeneratedLineups(data.lineups);
      setActiveLineupIdx(0);
      setSavedIndices(new Set());
    },
    onError: (err) => {
      toast({ title: "Optimization Failed", description: err.message, variant: "destructive" });
    },
  });

  // ── Save mutation
  const saveMutation = useMutation({
    mutationFn: async ({ lineup, idx }: { lineup: GeneratedLineup; idx: number }) => {
      const res = await apiRequest("POST", "/api/showdown/save", {
        slateId: activeSlateId,
        sport,
        platform,
        lineupData: lineup,
        name: `${sport} Showdown — ${lineup.captainName} ${captainLabel}`,
      });
      if (!res.ok) throw new Error("Failed to save");
      return { idx };
    },
    onSuccess: ({ idx }) => {
      setSavedIndices(prev => new Set(prev).add(idx));
      toast({ title: "Lineup Saved!", description: "Added to your vault." });
    },
    onError: () => {
      toast({ title: "Save Failed", variant: "destructive" });
    },
  });

  // ── Generate handler
  const handleGenerate = useCallback(() => {
    if (!activeSlateId) return;
    optimizeMutation.mutate({
      slateId: activeSlateId,
      sport,
      platform,
      captainId: lockedCaptainId || undefined,
      lockedFlexIds,
      excludedPlayerIds: excludedIds,
      lineupCount,
    });
  }, [activeSlateId, sport, platform, lockedCaptainId, lockedFlexIds, excludedIds, lineupCount]);

  // ── Lock/exclude toggles
  const toggleCaptain = useCallback((id: number) => {
    setLockedCaptainId(prev => prev === id ? null : id);
    setLockedFlexIds(prev => prev.filter(x => x !== id));
    setExcludedIds(prev => prev.filter(x => x !== id));
  }, []);

  const toggleFlex = useCallback((id: number) => {
    if (lockedCaptainId === id) return; // can't flex-lock the captain
    setLockedFlexIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
    setExcludedIds(prev => prev.filter(x => x !== id));
  }, [lockedCaptainId]);

  const toggleExclude = useCallback((id: number) => {
    if (lockedCaptainId === id) setLockedCaptainId(null);
    setLockedFlexIds(prev => prev.filter(x => x !== id));
    setExcludedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  }, [lockedCaptainId]);

  // ── CSV Export
  const handleExport = useCallback(() => {
    if (!activeLineup || platform !== "draftkings") {
      toast({ title: "Export DK only", description: "CSV export is for DraftKings.", variant: "destructive" });
      return;
    }
    const headers = ["CPT", "FLEX", "FLEX", "FLEX", "FLEX", "FLEX"];
    const rows = generatedLineups.map(lu => {
      const cpt = lu.players.find(p => p.isCaptain);
      const flex = lu.players.filter(p => !p.isCaptain);
      return [cpt, ...flex].map(p => {
        if (!p) return "";
        return p.draftKingsPlayerId ? `${p.name} (${p.draftKingsPlayerId})` : p.name;
      });
    });
    const csv = [headers.join(","), ...rows.map(r => r.map(c => `"${c}"`).join(","))].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `${sport}_showdown_${generatedLineups.length}_lineups.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    toast({ title: "CSV Exported", description: `${generatedLineups.length} lineup(s) downloaded.` });
  }, [activeLineup, generatedLineups, platform, sport]);

  // ── Active slate
  const activeSlate = sportSlates.find(s => s.id === activeSlateId);

  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-[calc(100vh-64px)] bg-slate-950 overflow-hidden">

      {/* ── Top bar ── */}
      <div className={`bg-gradient-to-r ${sColors.color} border-b border-slate-800/80 px-4 py-3 shrink-0`}>
        <div className="flex items-center gap-3 flex-wrap">

          {/* Sport toggle */}
          <div className="flex items-center bg-slate-900/80 border border-slate-700/60 rounded-xl p-1 gap-0.5">
            {(["NBA", "NFL"] as Sport[]).map(s => (
              <button
                key={s}
                onClick={() => setSport(s)}
                className={`px-4 py-1.5 rounded-lg text-xs font-black transition-all ${
                  sport === s
                    ? s === "NBA"
                      ? "bg-orange-500/20 text-orange-400 border border-orange-500/30"
                      : "bg-green-500/20 text-green-400 border border-green-500/30"
                    : "text-slate-400 hover:text-white"
                }`}
                data-testid={`sport-toggle-${s}`}
              >
                {s}
              </button>
            ))}
          </div>

          {/* Platform toggle */}
          <div className="flex items-center bg-slate-900/80 border border-slate-700/60 rounded-xl p-1 gap-0.5">
            {(["draftkings", "fanduel"] as Platform[]).map(p => (
              <button
                key={p}
                onClick={() => setPlatform(p)}
                className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${
                  platform === p
                    ? "bg-slate-700 text-white border border-slate-600/50"
                    : "text-slate-500 hover:text-slate-300"
                }`}
                data-testid={`platform-toggle-${p}`}
              >
                {p === "draftkings" ? "DK" : "FD"}
              </button>
            ))}
          </div>

          <div className="h-5 w-px bg-slate-700/60 hidden sm:block" />

          {/* Showdown badge */}
          <div className="flex items-center gap-2">
            <Swords className="w-4 h-4 text-amber-400" />
            <span className="text-sm font-black text-white tracking-tight">SHOWDOWN</span>
            <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-[9px] font-black">
              {captainLabel} {platform === "fanduel" ? "2×" : "1.5×"}
            </Badge>
          </div>

          {/* Slate selector */}
          {sportSlates.length > 0 && (
            <select
              className="ml-auto bg-slate-800/80 border border-slate-700/50 text-white text-xs font-bold rounded-lg px-3 py-1.5 max-w-[200px]"
              value={activeSlateId || ""}
              onChange={e => setSelectedSlateId(Number(e.target.value))}
              data-testid="showdown-slate-select"
            >
              {sportSlates.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} — {new Date(s.startTime).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* ── Game picker ── */}
      {games.length > 0 && (
        <div className="px-4 py-2.5 border-b border-slate-800/60 bg-slate-900/30 shrink-0 overflow-x-auto scrollbar-hide">
          <div className="flex items-center gap-2 min-w-max">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest shrink-0">Game</span>
            {games.map(game => (
              <button
                key={game.key}
                onClick={() => setSelectedGame(game.key)}
                data-testid={`game-pill-${game.key}`}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all shrink-0 ${
                  selectedGame === game.key
                    ? `${sColors.bg} ${sColors.border} ${sColors.accentText}`
                    : "bg-slate-800/50 border-slate-700/40 text-slate-400 hover:text-white hover:border-slate-600/60"
                }`}
              >
                <span className="font-black">{game.away}</span>
                <span className="text-slate-600 text-[10px]">@</span>
                <span className="font-black">{game.home}</span>
                <span className="text-[10px] text-slate-500 font-bold ml-1">{game.time}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── Mobile tab toggle ── */}
      <div className="xl:hidden flex border-b border-slate-800/60 bg-slate-900/50 shrink-0">
        {[["pool", "Player Pool"], ["lineup", "Lineup"]].map(([v, l]) => (
          <button
            key={v}
            onClick={() => setMobileView(v as any)}
            className={`flex-1 py-2.5 text-xs font-black uppercase tracking-widest transition-all ${
              mobileView === v
                ? `${sColors.accentText} border-b-2 ${sport === "NBA" ? "border-orange-400" : "border-green-400"} bg-slate-800/30`
                : "text-slate-500 hover:text-slate-300"
            }`}
          >
            {l}
          </button>
        ))}
      </div>

      {/* ── Main two-panel layout ── */}
      <div className="flex flex-1 overflow-hidden">

        {/* ── LEFT: Player pool ── */}
        <div className={`flex flex-col w-full xl:w-[55%] overflow-hidden border-r border-slate-800/60 ${mobileView !== "pool" ? "hidden xl:flex" : ""}`}>

          {/* Filter bar */}
          <div className="px-4 py-3 border-b border-slate-800/50 flex flex-col sm:flex-row gap-2.5 shrink-0">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500" />
              <Input
                placeholder="Search players…"
                className="pl-9 bg-slate-900/60 border-slate-700/50 h-8 text-sm"
                value={search}
                onChange={e => setSearch(e.target.value)}
                data-testid="showdown-search"
              />
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {/* Position filter */}
              <select
                className="bg-slate-800/80 border border-slate-700/50 text-xs font-bold text-white rounded-lg px-2.5 py-1.5 h-8"
                value={posFilter}
                onChange={e => setPosFilter(e.target.value)}
                data-testid="showdown-pos-filter"
              >
                {positions.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
              {/* Team filter */}
              <select
                className="bg-slate-800/80 border border-slate-700/50 text-xs font-bold text-white rounded-lg px-2.5 py-1.5 h-8"
                value={teamFilter}
                onChange={e => setTeamFilter(e.target.value)}
                data-testid="showdown-team-filter"
              >
                {teams.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="text-[11px] text-slate-500 font-bold self-center ml-auto shrink-0">
              {filteredPlayers.length} players
            </div>
          </div>

          {/* Player table */}
          <div className="flex-1 overflow-auto">
            <table className="w-full text-left border-collapse min-w-[560px]">
              <thead className="sticky top-0 z-10 bg-slate-900/95 border-b border-slate-800">
                <tr className="text-slate-500">
                  {/* CPT lock */}
                  <th className="px-3 py-2.5 w-10 text-center">
                    <Crown className="w-3.5 h-3.5 mx-auto text-amber-400/60" />
                  </th>
                  {/* FLEX lock */}
                  <th className="px-2 py-2.5 w-8 text-center">
                    <Lock className="w-3 h-3 mx-auto" />
                  </th>
                  {/* Exclude */}
                  <th className="px-2 py-2.5 w-8 text-center">
                    <X className="w-3 h-3 mx-auto" />
                  </th>
                  <th className="px-3 py-2.5 text-[10px] font-black uppercase tracking-wider">Player</th>
                  <th
                    className="px-3 py-2.5 text-[10px] font-black uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => { setSortKey("salary"); setSortDir(d => d === "asc" ? "desc" : "asc"); }}
                  >
                    Salary
                  </th>
                  <th
                    className="px-3 py-2.5 text-[10px] font-black uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => { setSortKey("proj"); setSortDir(d => d === "asc" ? "desc" : "asc"); }}
                  >
                    Proj
                  </th>
                  <th className="px-3 py-2.5 text-[10px] font-black uppercase tracking-wider text-amber-400/70">
                    {captainLabel} Proj
                  </th>
                  <th className="px-3 py-2.5 text-[10px] font-black uppercase tracking-wider text-amber-400/70">
                    {captainLabel} $
                  </th>
                </tr>
              </thead>
              <tbody>
                {playersLoading ? (
                  <tr><td colSpan={8} className="py-16 text-center">
                    <Loader2 className="w-6 h-6 text-slate-500 animate-spin mx-auto" />
                  </td></tr>
                ) : filteredPlayers.length === 0 ? (
                  <tr><td colSpan={8} className="py-12 text-center text-sm text-slate-500">
                    {selectedGame ? "No players found for this game" : "Select a game above"}
                  </td></tr>
                ) : filteredPlayers.map(p => {
                  const isCptLocked = lockedCaptainId === p.id;
                  const isFlexLocked = lockedFlexIds.includes(p.id);
                  const isExcluded = excludedIds.includes(p.id);
                  const injColor = p.injuryStatus ? (INJURY_COLORS[p.injuryStatus] || "text-slate-500") : "";

                  return (
                    <tr
                      key={p.id}
                      className={`border-b border-slate-800/40 transition-colors ${
                        isExcluded ? "opacity-30" :
                        isCptLocked ? "bg-amber-500/5" :
                        isFlexLocked ? "bg-blue-500/5" :
                        "hover:bg-slate-800/25"
                      }`}
                      data-testid={`showdown-player-row-${p.id}`}
                    >
                      {/* CPT lock */}
                      <td className="px-3 py-2 text-center">
                        <button
                          onClick={() => toggleCaptain(p.id)}
                          className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all mx-auto ${
                            isCptLocked
                              ? "bg-amber-500/25 border border-amber-500/50 text-amber-400"
                              : "bg-slate-800/60 border border-slate-700/40 text-slate-600 hover:text-amber-400 hover:border-amber-500/30"
                          }`}
                          title={isCptLocked ? `Unlock ${captainLabel}` : `Lock as ${captainLabel}`}
                          data-testid={`cpt-toggle-${p.id}`}
                        >
                          <Crown className="w-3.5 h-3.5" />
                        </button>
                      </td>

                      {/* FLEX lock */}
                      <td className="px-2 py-2 text-center">
                        <button
                          onClick={() => toggleFlex(p.id)}
                          disabled={isCptLocked}
                          className={`w-6 h-6 rounded-md flex items-center justify-center transition-all mx-auto ${
                            isFlexLocked
                              ? "bg-blue-500/20 border border-blue-500/40 text-blue-400"
                              : "text-slate-600 hover:text-blue-400 disabled:opacity-20"
                          }`}
                          data-testid={`flex-toggle-${p.id}`}
                        >
                          {isFlexLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                        </button>
                      </td>

                      {/* Exclude */}
                      <td className="px-2 py-2 text-center">
                        <button
                          onClick={() => toggleExclude(p.id)}
                          className={`w-6 h-6 rounded-md flex items-center justify-center transition-all mx-auto ${
                            isExcluded
                              ? "bg-red-500/20 border border-red-500/30 text-red-400"
                              : "text-slate-700 hover:text-red-400"
                          }`}
                          data-testid={`exclude-toggle-${p.id}`}
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </td>

                      {/* Player info */}
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-black w-7 shrink-0 ${posColor(p.position)}`}>
                            {p.position.split("/")[0]}
                          </span>
                          <div>
                            <p className="text-sm font-bold text-white leading-tight">{p.name}</p>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <TeamChip team={p.team} sport={sport} />
                              {p.injuryStatus && (
                                <span className={`text-[9px] font-black ${injColor}`}>
                                  {p.injuryStatus}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Base salary */}
                      <td className="px-3 py-2 text-xs font-bold text-slate-300 tabular-nums">
                        ${p.salary.toLocaleString()}
                      </td>

                      {/* Base proj */}
                      <td className="px-3 py-2 text-sm font-black text-emerald-400 tabular-nums">
                        {Number(p.projectedPoints).toFixed(1)}
                      </td>

                      {/* CPT proj */}
                      <td className="px-3 py-2 text-sm font-black text-amber-400 tabular-nums">
                        {p.captainProj.toFixed(1)}
                      </td>

                      {/* CPT salary */}
                      <td className="px-3 py-2 text-xs font-bold text-amber-300/80 tabular-nums">
                        ${p.captainSalary.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* ── RIGHT: Lineup builder ── */}
        <div className={`flex flex-col w-full xl:w-[45%] overflow-hidden ${mobileView !== "lineup" ? "hidden xl:flex" : ""}`}>

          {/* Generate controls */}
          <div className="px-5 py-3.5 border-b border-slate-800/60 bg-slate-900/30 shrink-0">
            <div className="flex items-center gap-3 flex-wrap">
              {/* Lineup count */}
              <div className="flex items-center gap-2 bg-slate-800/60 border border-slate-700/40 rounded-xl px-3 py-1.5">
                <span className="text-[10px] font-black text-slate-400 uppercase">Qty</span>
                <button onClick={() => setLineupCount(c => Math.max(1, c - 1))} className="text-slate-400 hover:text-white w-5 text-center font-black">−</button>
                <span className="text-sm font-black text-white w-6 text-center tabular-nums">{lineupCount}</span>
                <button onClick={() => setLineupCount(c => Math.min(20, c + 1))} className="text-slate-400 hover:text-white w-5 text-center font-black">+</button>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={optimizeMutation.isPending || !activeSlateId || !selectedGame}
                className={`flex-1 font-black text-sm h-9 ${
                  sport === "NBA"
                    ? "bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-500/20"
                    : "bg-green-600 hover:bg-green-700 text-white shadow-lg shadow-green-500/20"
                }`}
                data-testid="showdown-generate"
              >
                {optimizeMutation.isPending
                  ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Optimizing…</>
                  : <><Zap className="w-3.5 h-3.5 mr-1.5" />Generate {lineupCount > 1 ? `${lineupCount} Lineups` : "Lineup"}</>
                }
              </Button>

              {generatedLineups.length > 0 && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleExport}
                    className="border-slate-700 text-slate-300 h-9 font-bold"
                    data-testid="showdown-export"
                  >
                    <Download className="w-3.5 h-3.5 mr-1" />
                    CSV
                  </Button>
                </>
              )}
            </div>

            {/* Locks summary */}
            {(lockedCaptainId || lockedFlexIds.length > 0) && (
              <div className="flex flex-wrap gap-1.5 mt-2.5">
                {lockedCaptainId && (() => {
                  const p = allPlayers.find(x => x.id === lockedCaptainId);
                  return p ? (
                    <span className="inline-flex items-center gap-1 bg-amber-500/15 border border-amber-500/30 rounded-lg px-2 py-1 text-[10px] font-bold text-amber-400">
                      <Crown className="w-3 h-3" /> {p.name}
                      <button onClick={() => setLockedCaptainId(null)} className="ml-0.5 hover:text-white"><X className="w-2.5 h-2.5" /></button>
                    </span>
                  ) : null;
                })()}
                {lockedFlexIds.map(id => {
                  const p = allPlayers.find(x => x.id === id);
                  return p ? (
                    <span key={id} className="inline-flex items-center gap-1 bg-blue-500/10 border border-blue-500/25 rounded-lg px-2 py-1 text-[10px] font-bold text-blue-400">
                      <Lock className="w-3 h-3" /> {p.name}
                      <button onClick={() => toggleFlex(id)} className="ml-0.5 hover:text-white"><X className="w-2.5 h-2.5" /></button>
                    </span>
                  ) : null;
                })}
              </div>
            )}
          </div>

          {/* Lineup tabs (if multiple) */}
          {generatedLineups.length > 1 && (
            <div className="flex border-b border-slate-800/60 overflow-x-auto scrollbar-hide shrink-0 bg-slate-900/20">
              {generatedLineups.map((lu, i) => (
                <button
                  key={i}
                  onClick={() => setActiveLineupIdx(i)}
                  data-testid={`showdown-lineup-tab-${i}`}
                  className={`px-4 py-2.5 text-xs font-black shrink-0 border-b-2 transition-all ${
                    i === activeLineupIdx
                      ? `${sColors.accentText} ${sport === "NBA" ? "border-orange-400" : "border-green-400"}`
                      : "text-slate-500 border-transparent hover:text-slate-300"
                  }`}
                >
                  #{i + 1} {lu.captainName.split(" ").pop()}
                  {savedIndices.has(i) && <span className="ml-1 text-emerald-400">✓</span>}
                </button>
              ))}
            </div>
          )}

          {/* Lineup content */}
          <div className="flex-1 overflow-auto">
            {!activeLineup && !optimizeMutation.isPending && (
              <div className="flex flex-col items-center justify-center h-full py-16 text-center px-6">
                <div className={`w-16 h-16 rounded-2xl ${sColors.bg} border ${sColors.border} flex items-center justify-center mb-5`}>
                  <Swords className={`w-8 h-8 ${sColors.accentText}`} />
                </div>
                <p className="text-lg font-black text-white mb-2">Build Your Showdown</p>
                <p className="text-sm text-slate-400 max-w-xs">
                  Pick a game, optionally lock your {captainLabel}, then hit Generate.
                  The {captainLabel} scores {getCaptainMultiplier(platform)}× points.
                </p>
              </div>
            )}

            {optimizeMutation.isPending && (
              <div className="flex flex-col items-center justify-center h-full">
                <Loader2 className={`w-10 h-10 ${sColors.accentText} animate-spin mb-3`} />
                <p className="text-sm font-bold text-slate-400">Building lineups…</p>
              </div>
            )}

            {activeLineup && !optimizeMutation.isPending && (
              <div className="p-5 space-y-3">
                {/* Captain slot */}
                {activeLineup.players.filter(p => p.isCaptain).map(p => (
                  <div
                    key={p.id}
                    className="relative rounded-xl border border-amber-500/30 overflow-hidden"
                    data-testid={`lineup-slot-${p.slot}`}
                  >
                    <CaptainGlow sport={sport} />
                    <div className="relative flex items-center gap-3 px-4 py-3.5">
                      <SlotBadge isCaptain platform={platform} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`text-[11px] font-black ${posColor(p.position)}`}>{p.position.split("/")[0]}</span>
                          <p className="text-base font-black text-white truncate">{p.name}</p>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <TeamChip team={p.team} sport={sport} />
                          {p.injuryStatus && (
                            <span className={`text-[9px] font-black ${INJURY_COLORS[p.injuryStatus] || "text-slate-500"}`}>
                              {p.injuryStatus}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-xl font-black text-amber-400 tabular-nums">{p.effectiveProjection.toFixed(1)}</p>
                        <p className="text-[10px] text-amber-300/60 font-bold">${p.effectiveSalary.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                ))}

                {/* FLEX slots */}
                {activeLineup.players.filter(p => !p.isCaptain).map((p, i) => (
                  <div
                    key={p.id}
                    className="rounded-xl border border-slate-700/50 bg-slate-900/50 hover:border-slate-600/60 transition-colors"
                    data-testid={`lineup-slot-${p.slot}`}
                  >
                    <div className="flex items-center gap-3 px-4 py-3">
                      <SlotBadge isCaptain={false} platform={platform} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`text-[11px] font-black ${posColor(p.position)}`}>{p.position.split("/")[0]}</span>
                          <p className="text-sm font-bold text-white truncate">{p.name}</p>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <TeamChip team={p.team} sport={sport} />
                          {p.injuryStatus && (
                            <span className={`text-[9px] font-black ${INJURY_COLORS[p.injuryStatus] || "text-slate-500"}`}>
                              {p.injuryStatus}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-sm font-black text-emerald-400 tabular-nums">{p.effectiveProjection.toFixed(1)}</p>
                        <p className="text-[10px] text-slate-500 font-bold">${p.effectiveSalary.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Totals */}
                <div className={`rounded-xl ${sColors.bg} border ${sColors.border} p-4`}>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <p className={`text-xl font-black tabular-nums ${sColors.accentText}`}>
                        {activeLineup.totalProjectedPoints.toFixed(1)}
                      </p>
                      <p className="text-[10px] font-bold text-slate-500 uppercase mt-0.5">Proj Pts</p>
                    </div>
                    <div className="text-center border-x border-slate-700/40">
                      <p className={`text-xl font-black tabular-nums ${
                        activeLineup.totalSalary > (platform === "fanduel" ? 60000 : 50000)
                          ? "text-red-400" : "text-white"
                      }`}>
                        ${activeLineup.totalSalary.toLocaleString()}
                      </p>
                      <p className="text-[10px] font-bold text-slate-500 uppercase mt-0.5">
                        of ${(platform === "fanduel" ? 60000 : 50000).toLocaleString()}
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-xl font-black text-amber-400">
                        {activeLineup.captainName.split(" ").pop()}
                      </p>
                      <p className="text-[10px] font-bold text-slate-500 uppercase mt-0.5">{captainLabel}</p>
                    </div>
                  </div>
                </div>

                {/* Save button */}
                <Button
                  onClick={() => saveMutation.mutate({ lineup: activeLineup, idx: activeLineupIdx })}
                  disabled={!user || saveMutation.isPending || savedIndices.has(activeLineupIdx)}
                  className={`w-full h-10 font-black text-sm ${
                    savedIndices.has(activeLineupIdx)
                      ? "bg-emerald-600/20 border border-emerald-500/30 text-emerald-400"
                      : "bg-slate-800 hover:bg-slate-700 border border-slate-700/50 text-white"
                  }`}
                  data-testid="showdown-save"
                >
                  {saveMutation.isPending
                    ? <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    : savedIndices.has(activeLineupIdx)
                    ? <><Trophy className="w-4 h-4 mr-2 text-emerald-400" />Saved!</>
                    : <><Save className="w-4 h-4 mr-2" />Save Lineup</>
                  }
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
