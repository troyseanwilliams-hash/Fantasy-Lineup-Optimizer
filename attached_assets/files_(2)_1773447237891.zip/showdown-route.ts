// ============================================================
// SHOWDOWN OPTIMIZER ROUTE — server/routes/showdown.ts
// Mount: app.use(showdownRouter)
//
// POST /api/showdown/optimize
//   Runs a simple greedy optimizer for showdown lineups.
//   Tries every eligible player as CPT/MVP, fills the rest
//   greedily by projected points under the salary cap.
// ============================================================

import { Router } from "express";
import { eq, and } from "drizzle-orm";
import { z } from "zod";
import { db } from "../db";
import { players, slates, lineups } from "../../shared/schema";
import {
  getShowdownConfig,
  getEffectiveSalary,
  getProjectedPoints,
  type ShowdownConfig,
  type ShowdownSlot,
} from "../../shared/showdown-config";

const router = Router();

// ── Request schema ────────────────────────────────────────────────────────────

const showdownOptimizeSchema = z.object({
  slateId: z.number(),
  sport: z.enum(["NBA", "NFL"]),
  platform: z.enum(["draftkings", "fanduel"]),
  captainId: z.number().optional(),        // lock a specific CPT/MVP
  lockedFlexIds: z.array(z.number()).default([]),
  excludedPlayerIds: z.array(z.number()).default([]),
  lineupCount: z.number().min(1).max(20).default(1),
  // Optional: restrict to one team's players for stacking
  preferTeam: z.string().optional(),
});

type ShowdownOptimizeRequest = z.infer<typeof showdownOptimizeSchema>;

interface ShowdownLineupPlayer {
  id: number;
  name: string;
  team: string;
  position: string;
  baseSalary: number;
  effectiveSalary: number;
  baseProjection: number;
  effectiveProjection: number;
  slot: string;
  isCaptain: boolean;
  injuryStatus: string | null;
  draftKingsPlayerId: number | null;
}

interface ShowdownLineup {
  players: ShowdownLineupPlayer[];
  totalSalary: number;
  totalProjectedPoints: number;
  captainName: string;
  captainTeam: string;
  error?: string;
}

// ── Optimizer core ────────────────────────────────────────────────────────────

function buildShowdownLineup(
  pool: typeof players.$inferSelect[],
  config: ShowdownConfig,
  captainId: number | null,
  lockedFlexIds: number[],
  excludedIds: Set<number>,
): ShowdownLineup | null {
  const captainSlot = config.slots.find(s => s.isCaptain)!;
  const flexSlots = config.slots.filter(s => !s.isCaptain);
  const totalSlots = config.slots.length;

  // Eligible pool (not excluded)
  const eligible = pool.filter(p => !excludedIds.has(p.id));
  if (eligible.length < totalSlots) return null;

  // Determine captain
  let captain: typeof pool[0] | undefined;
  if (captainId) {
    captain = eligible.find(p => p.id === captainId);
    if (!captain) return null;
  } else {
    // Default: highest projected player
    captain = eligible.reduce((best, p) =>
      Number(p.projectedPoints) > Number(best.projectedPoints) ? p : best
    );
  }

  const captainEffSalary = getEffectiveSalary(captain.salary, captainSlot);
  const captainEffProj = getProjectedPoints(Number(captain.projectedPoints), captainSlot);

  // Remaining budget after captain
  let remaining = config.salaryCap - captainEffSalary;
  if (remaining < 0) return null;

  // Flex pool: everyone except the captain
  const flexEligible = eligible.filter(p => p.id !== captain!.id);

  // Start with locked flex players
  const lockedFlex = lockedFlexIds
    .map(id => flexEligible.find(p => p.id === id))
    .filter(Boolean) as typeof pool;

  // Check locked flex players fit in budget
  const lockedFlexSalary = lockedFlex.reduce((s, p) => s + p.salary, 0);
  if (lockedFlexSalary > remaining) return null;
  remaining -= lockedFlexSalary;

  // Fill remaining flex slots greedily by projected points / salary value
  const needMore = flexSlots.length - lockedFlex.length;
  const remainingFlex = flexEligible.filter(
    p => !lockedFlex.some(l => l.id === p.id)
  );

  // Sort by projected points descending, filtered by affordability
  const affordable = remainingFlex.filter(p => p.salary <= remaining);
  affordable.sort((a, b) => Number(b.projectedPoints) - Number(a.projectedPoints));

  // Greedy fill — pick best affordable players
  const chosen: typeof pool = [];
  let budgetLeft = remaining;
  for (const p of affordable) {
    if (chosen.length >= needMore) break;
    if (p.salary <= budgetLeft) {
      chosen.push(p);
      budgetLeft -= p.salary;
    }
  }

  if (chosen.length < needMore) return null;

  const allFlex = [...lockedFlex, ...chosen];
  const totalSalary = captainEffSalary + allFlex.reduce((s, p) => s + p.salary, 0);
  const totalProj = captainEffProj + allFlex.reduce((s, p) => s + Number(p.projectedPoints), 0);

  const resultPlayers: ShowdownLineupPlayer[] = [
    {
      id: captain.id,
      name: captain.name,
      team: captain.team,
      position: captain.position,
      baseSalary: captain.salary,
      effectiveSalary: captainEffSalary,
      baseProjection: Number(captain.projectedPoints),
      effectiveProjection: captainEffProj,
      slot: captainSlot.key,
      isCaptain: true,
      injuryStatus: captain.injuryStatus,
      draftKingsPlayerId: captain.draftKingsPlayerId,
    },
    ...allFlex.map((p, i) => ({
      id: p.id,
      name: p.name,
      team: p.team,
      position: p.position,
      baseSalary: p.salary,
      effectiveSalary: p.salary,
      baseProjection: Number(p.projectedPoints),
      effectiveProjection: Number(p.projectedPoints),
      slot: flexSlots[i].key,
      isCaptain: false,
      injuryStatus: p.injuryStatus,
      draftKingsPlayerId: p.draftKingsPlayerId,
    })),
  ];

  return {
    players: resultPlayers,
    totalSalary: Math.round(totalSalary),
    totalProjectedPoints: Math.round(totalProj * 100) / 100,
    captainName: captain.name,
    captainTeam: captain.team,
  };
}

// ── Routes ────────────────────────────────────────────────────────────────────

// GET /api/showdown/slates — get showdown-eligible slates (single-game slates)
// In practice these are slates where isMain = false or a dedicated showdown flag
// For now returns all slates for the given sport so the user can pick a game
router.get("/api/showdown/slates", async (req, res) => {
  try {
    const { sport } = req.query;
    const allSlates = await db
      .select()
      .from(slates)
      .where(sport ? eq(slates.sport, String(sport)) : undefined)
      .orderBy(slates.startTime);

    return res.json(allSlates);
  } catch (err: any) {
    return res.status(500).json({ message: "Failed to fetch slates" });
  }
});

// GET /api/showdown/players/:slateId — players for a showdown slate
router.get("/api/showdown/players/:slateId", async (req, res) => {
  try {
    const { slateId } = req.params;
    const slatePlayerData = await db
      .select()
      .from(players)
      .where(eq(players.slateId, Number(slateId)));

    // Group by game (team matchup) for the game picker
    const games = new Map<string, { away: string; home: string; time: string; players: typeof slatePlayerData }>();
    for (const p of slatePlayerData) {
      const gameKey = p.gameInfo || `${p.team}-${p.opponent}`;
      if (!games.has(gameKey)) {
        // Parse "AWAY @ HOME TIME" or "HOME vs AWAY TIME"
        let away = p.opponent || "";
        let home = p.team;
        if (p.gameInfo?.includes("@")) {
          const parts = p.gameInfo.split("@");
          away = parts[0].trim().split(" ").pop() || p.team;
          home = (parts[1] || "").trim().split(" ")[0];
        } else if (p.gameInfo?.includes("vs")) {
          const parts = p.gameInfo.split("vs");
          home = parts[0].trim().split(" ").pop() || p.team;
          away = (parts[1] || "").trim().split(" ")[0];
        }
        const timePart = p.gameInfo?.split(" ").slice(-2).join(" ") || "";
        games.set(gameKey, { away, home, time: timePart, players: [] });
      }
      games.get(gameKey)!.players.push(p);
    }

    return res.json({
      players: slatePlayerData,
      games: Array.from(games.entries()).map(([key, g]) => ({
        key,
        away: g.away,
        home: g.home,
        time: g.time,
        playerCount: g.players.length,
      })),
    });
  } catch (err: any) {
    return res.status(500).json({ message: "Failed to fetch players" });
  }
});

// POST /api/showdown/optimize — generate showdown lineup(s)
router.post("/api/showdown/optimize", async (req, res) => {
  try {
    const parsed = showdownOptimizeSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: "Invalid request", errors: parsed.error.flatten() });
    }

    const { slateId, sport, platform, captainId, lockedFlexIds, excludedPlayerIds, lineupCount } = parsed.data;

    const config = getShowdownConfig(sport, platform);
    const excludedSet = new Set(excludedPlayerIds);

    // Fetch players for this slate
    const pool = await db
      .select()
      .from(players)
      .where(eq(players.slateId, slateId));

    if (pool.length < config.slots.length) {
      return res.status(400).json({ message: `Not enough players (${pool.length}) for a ${config.slots.length}-player showdown lineup` });
    }

    const generatedLineups: ShowdownLineup[] = [];

    if (captainId) {
      // Fixed captain — generate variations by exploring different flex combinations
      const lineup = buildShowdownLineup(pool, config, captainId, lockedFlexIds, excludedSet);
      if (!lineup) {
        return res.status(400).json({ message: "Could not build lineup with the selected captain and constraints" });
      }
      generatedLineups.push(lineup);

      // Generate additional lineups by rotating the flex pool
      if (lineupCount > 1) {
        const usedFlexCombos = new Set<string>([
          lineup.players.filter(p => !p.isCaptain).map(p => p.id).sort().join(",")
        ]);

        for (let attempt = 0; generatedLineups.length < lineupCount && attempt < 100; attempt++) {
          // Exclude one of the previously used flex players to force variety
          const prevLineup = generatedLineups[generatedLineups.length - 1];
          const flexPlayers = prevLineup.players.filter(p => !p.isCaptain && !lockedFlexIds.includes(p.id));
          if (flexPlayers.length === 0) break;

          const rotateOut = flexPlayers[attempt % flexPlayers.length];
          const newExcluded = new Set([...excludedSet, rotateOut.id]);
          const newLineup = buildShowdownLineup(pool, config, captainId, lockedFlexIds, newExcluded);
          if (!newLineup) continue;

          const comboKey = newLineup.players.filter(p => !p.isCaptain).map(p => p.id).sort().join(",");
          if (usedFlexCombos.has(comboKey)) continue;
          usedFlexCombos.add(comboKey);
          generatedLineups.push(newLineup);
        }
      }
    } else {
      // Try each player as captain and pick the highest-projected lineup
      const sortedPool = [...pool]
        .filter(p => !excludedSet.has(p.id))
        .sort((a, b) => Number(b.projectedPoints) - Number(a.projectedPoints));

      const triedCaptains = new Set<number>();
      const usedFlexCombos = new Set<string>();

      for (const candidate of sortedPool) {
        if (generatedLineups.length >= lineupCount) break;
        if (triedCaptains.has(candidate.id)) continue;
        triedCaptains.add(candidate.id);

        const lineup = buildShowdownLineup(pool, config, candidate.id, lockedFlexIds, excludedSet);
        if (!lineup) continue;

        const comboKey = [candidate.id, ...lineup.players.filter(p => !p.isCaptain).map(p => p.id).sort()].join(",");
        if (usedFlexCombos.has(comboKey)) continue;
        usedFlexCombos.add(comboKey);
        generatedLineups.push(lineup);
      }
    }

    if (generatedLineups.length === 0) {
      return res.status(400).json({ message: "Could not generate any valid showdown lineups. Try relaxing your constraints." });
    }

    return res.json({
      lineups: generatedLineups,
      config: {
        salaryCap: config.salaryCap,
        slots: config.slots,
        platform: config.platform,
        sport: config.sport,
      },
    });
  } catch (err: any) {
    console.error("[showdown/optimize]", err);
    return res.status(500).json({ message: err.message || "Optimization failed" });
  }
});

// POST /api/showdown/save — save a showdown lineup to the lineups table
router.post("/api/showdown/save", async (req, res) => {
  if (!req.user) return res.status(401).json({ message: "Unauthorized" });

  try {
    const userId = (req.user as any).id;
    const { slateId, sport, platform, lineupData, name } = req.body;

    if (!slateId || !sport || !platform || !lineupData) {
      return res.status(400).json({ message: "slateId, sport, platform, and lineupData required" });
    }

    const lineupPlayers = lineupData.players as ShowdownLineupPlayer[];
    const playerIds = lineupPlayers.map(p => p.id);

    const saved = await db.insert(lineups).values({
      userId,
      slateId,
      sport,
      platform,
      totalSalary: lineupData.totalSalary,
      totalProjectedPoints: String(lineupData.totalProjectedPoints),
      playerIds,
      playerSnapshot: lineupPlayers,
      name: name || `Showdown — ${lineupData.captainName} CPT`,
      status: "active",
    }).returning();

    return res.status(201).json(saved[0]);
  } catch (err: any) {
    console.error("[showdown/save]", err);
    return res.status(500).json({ message: "Failed to save lineup" });
  }
});

export default router;
